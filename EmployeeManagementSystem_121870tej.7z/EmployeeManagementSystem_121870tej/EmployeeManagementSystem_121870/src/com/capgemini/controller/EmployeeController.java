package com.capgemini.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.bean.Employee;

import com.capgemini.service.IEmployeeService;


@Controller
public class EmployeeController {
	
	@Autowired
	private IEmployeeService employeeService;

	public IEmployeeService getEmployeeService() {
		return employeeService;
	}

	public void setEmployeeService(IEmployeeService employeeService) {
		this.employeeService = employeeService;
	}

	public EmployeeController(IEmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}

	public EmployeeController() {
	
	}
	@RequestMapping("addEmployee")
	public String AddEmployeePage(Model model)
	{
		List<String> Gender = new ArrayList<>();
		Gender.add("Male");
		Gender.add("Female");
		
		List<String> Designation = new ArrayList<>();
		Designation.add("Select");
		Designation.add("Software Engineer");
		Designation.add("Senior Software Enginner");
		Designation.add("Team Lead");
		Designation.add("Manager");
		model.addAttribute("Gender", Gender);
		model.addAttribute("Designation", Designation);
		model.addAttribute("employee1", new Employee());
		return "AddEmployeePage";
		
	}
	
	@RequestMapping(value="processaddemployee")
	public ModelAndView ProcessAddEmployee(
			@ModelAttribute("employee1") @Valid Employee employee1, BindingResult result
			,Model model)
			{
				if(result.hasErrors()==true)
				{

					List<String> Gender = new ArrayList<>();
					Gender.add("Male");
					Gender.add("Female");
					
					List<String> Designation = new ArrayList<>();
					Designation.add("Select");
					Designation.add("Software Engineer");
					Designation.add("Senior Software Enginner");
					Designation.add("Team Lead");
					Designation.add("Manager");
					model.addAttribute("Gender", Gender);
					model.addAttribute("Designation", Designation);
					model.addAttribute("employee1", employee1);
					return new ModelAndView("AddProductPage");
				}
				int employeeid = -1;
				try
				{
					employeeid = employeeService.addEmployee(employee1);
						model.addAttribute("message", "Employee added Successfully and the employee code is"+employeeid);
						return new ModelAndView("SuccessPage");
					}
					catch(Exception e)
					{
						
						model.addAttribute("errMsg", "Could not add Employee");
					
					return new ModelAndView("ErrorPage");
					}
				}
	
	@RequestMapping("viewEmployee")
	public String getAllEmployee(Model model)
	{
		List<Employee> employees = null;
		try
		{
			employees = employeeService.getAllEmployees();
			model.addAttribute("employees", employees);
		}
		catch(Exception E)
		{
			model.addAttribute("errMsg", "Could not display the Employee Reason:"+E.getMessage());
			return "ErrorPage";
		}
		return "ViewAllEmployee";
	}
			}
	


