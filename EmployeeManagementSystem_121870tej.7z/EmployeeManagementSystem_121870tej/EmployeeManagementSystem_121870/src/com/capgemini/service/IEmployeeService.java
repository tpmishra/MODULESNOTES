package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.Employee;
import com.capgemini.exception.EmployeeException;

public interface IEmployeeService {
	
	public int addEmployee(Employee employee1) throws EmployeeException;
	public List<Employee> getAllEmployees() throws EmployeeException;

}
