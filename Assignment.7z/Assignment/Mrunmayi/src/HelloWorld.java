import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class HelloWorld
{
		public static void main(String args[]){
			
			
	String s="Ani ta";
	String pattern ="^[A-Z]{1}[a-z]{4}";
	//"^[0-9]{3}+_[0-9]{4}+_[0-9]{3}$"
	boolean matcher = Pattern.matches(pattern,s);
	System.out.println(matcher);
			
		}
}