import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;


public class TestProperty {
	
	public static void writeProperty(){
		
		Properties prop = new Properties();
		OutputStream ouput=null;
		
		try {
			ouput = new FileOutputStream("mrun.properties");
			
			prop.setProperty("oracle.driver", "oracle.jdbc.driver.OracleDriver");
			prop.setProperty("oracle.url", "jdbc.oracle.thin:@localhost:1521:xe");
			prop.setProperty("oracle.unmae", "labg104trg37@orcl11g");
			prop.setProperty("oracle.unpass", "labg104oracle");
			
			prop.store(ouput, null);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				ouput.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}
	
	public static void loadProperty(){
		Properties prop = new Properties();
		InputStream input = null;
		
		try {
			input = new FileInputStream("mrun.properties");
			prop.load(input);
			
			System.out.println(prop.getProperty("oracle.driver"));
			System.out.println(prop.getProperty("oracle.url"));
			System.out.println(prop.getProperty("oracle.unmae"));
			System.out.println(prop.getProperty("oracle.unpass"));
		}  catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				input.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

	public static void main(String[] args) {
		

		writeProperty();
		loadProperty();
	}

}
