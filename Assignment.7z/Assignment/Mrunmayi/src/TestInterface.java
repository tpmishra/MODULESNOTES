@FunctionalInterface
public interface TestInterface {

	
	public int fun(int x);
}
