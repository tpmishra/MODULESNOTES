package com.Mrunmayi.Assignment2;

public class DetPerson {

	Gender gender;
	private String fName;
	private String LName;
	private int phoneNo;
	
	public DetPerson(String fName, String lName, Gender gender, int phoneNo ) {
		super(); //parameterized constructor
		this.fName = fName;
		this.LName = lName;
		this.gender = gender;
		this.phoneNo = phoneNo;
	}
	
	public void show(){
		System.out.println("Person Details");
		System.out.println("------------------------------");
		System.out.println("First name: "+fName);
		System.out.println("Last name: "+LName);
		System.out.println("Gender: "+gender);
		System.out.println("Phone Number: "+phoneNo);
		System.out.println("------------------------------");
	}
}
