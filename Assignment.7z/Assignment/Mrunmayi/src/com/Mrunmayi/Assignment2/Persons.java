package com.Mrunmayi.Assignment2;

public class Persons {
String fName,LName;
char gender;
int phoneNo;
	
	

	public Persons(String fName, String lName, char gender, int phoneNo ) {
		super(); //parameterized constructor
		this.fName = fName;
		this.LName = lName;
		this.gender = gender;
		this.phoneNo = phoneNo;
	}
	
	public Persons(){
		super(); //default constructor
	}

	//getters and setters
	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getLName() {
		return LName;
	}

	public void setLName(String lName) {
		LName = lName;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}
	
	public int getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(int phoneNo) {
		this.phoneNo = phoneNo;
	}

	
	//method to display 
	public void show(){
		System.out.println("Person Details");
		System.out.println("------------------------------");
		System.out.println("First name: "+fName);
		System.out.println("Last name: "+LName);
		System.out.println("Gender: "+gender);
		System.out.println("Phone Number: "+phoneNo);
		System.out.println("------------------------------");
	}
	
}
