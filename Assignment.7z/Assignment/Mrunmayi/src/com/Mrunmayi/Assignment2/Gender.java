package com.Mrunmayi.Assignment2;

public enum Gender {

		M,F;
		
	/*private String ch;

	private void setGender(String ch){
		this.ch = ch;
	}
	
	public String getGender(){
		return ch;
	}*/
}
