package com.Mrunmayi.Assignment6.Assign62;



public class Account {

	public static int COUNT;
	private long accNum;
	private double balance;
	

	private Person accHolder;
	

	
	public Account(){
		super();
	}

	public Account(double balance) {
		super();
		COUNT++;
		accNum = COUNT;
		this.balance = balance;
	}


	public Person getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}

	
	
	public double getBalance() {
		return balance;
	}
	


	public void deposit(double amount) {
		balance += amount;
		
	}

	public void withdraw(double amount) {
		balance -= amount;
		
	}

	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", Initial balance=" + balance+" accHolder=" + accHolder + "]";
	}

}
