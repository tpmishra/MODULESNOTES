package com.Mrunmayi.Assignment6.Assign62;

public class Person {

	private String name;
	private float age;
	public Person(String name, float age) {
		super();
		this.name = name;
		this.age = age;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}

	

}
