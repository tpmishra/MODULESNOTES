package com.Mrunmayi.Assignment3;

public class PositiveString {

	public void checkPositive(String str) {
		int len = str.length();
		int arr[] = new int[len];
		int count = 1;

		for (int i = 0; i < len; i++) {
			arr[i] = str.charAt(i);
			System.out.println(arr[i]);
		}

		for (int i = 0; i < len; i++) {
			for(int j=1;j<len;j++){
			if (arr[i] <= arr[j]) {
				count = 0;
			}
			else{
				count=1;
				break;
			}
		}
		}

		if (count == 0) {
			System.out.println(str + " is a positive string");
		} else {
			System.out.println(str + " is a negative string");
		}

	}

}
