package com.Mrunmayi.Assignment7;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class ProductArrayList {

	public static void main(String[] args) {
	
		Scanner sc =new Scanner(System.in);
		List<String>aList = new ArrayList<>();
		System.out.println("enter");
		
		for(int i=0;i<5;i++){
		/*aList.add("Tea");
		aList.add("Coffee");
		aList.add("Powder");
		aList.add("Maggi");
		aList.add("Fruits");*/
			String str=sc.nextLine();
		aList.add(str);
		}
		System.out.println("Before Sorting--->");
		System.out.println(aList);

		Collections.sort(aList);
		
		System.out.println("After Sorting--->");
		
		for(String s:aList)
		System.out.println(s);
	}

}
