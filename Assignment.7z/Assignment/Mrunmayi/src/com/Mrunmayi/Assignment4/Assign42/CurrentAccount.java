package com.Mrunmayi.Assignment4.Assign42;

public class CurrentAccount extends Account {

	public int balance=500;
	public int x=0;
	public int overDraftLimit=10000;
	public boolean withdraw(int amount){
		
		x= amount-balance;
		if(x<=overDraftLimit){
			if(x<0){
				x=-x;
			}
			return true;
		}
		else{
			return false;
		}
	}
}
