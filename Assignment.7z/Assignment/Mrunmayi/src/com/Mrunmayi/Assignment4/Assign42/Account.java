package com.Mrunmayi.Assignment4.Assign42;

public class Account {

	public boolean withdraw(int amount){
		
		return false;
	}
}
	
