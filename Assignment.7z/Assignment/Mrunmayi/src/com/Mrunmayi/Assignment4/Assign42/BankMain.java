package com.Mrunmayi.Assignment4.Assign42;

public class BankMain {

	public static void main(String[] args) {
		
		SavingAccount sa = new SavingAccount();
		if(sa.withdraw(1000)){
			System.out.println("Cannot Withdraw due to low balance");
		}
		else{
			System.out.println("Can proceed with the withdraw transaction");
		}
		
		CurrentAccount ca = new CurrentAccount();
		if(ca.withdraw(15000)){
			System.out.println("Balance is Rs.0 and Over draft amount is: "+ca.x);
		}
		else{
			System.out.println("Over draft limit exceeded. Cannot proceed with the transaction");
		}

	}

}
