import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class TestJdbc {

	public static void main(String[] args) {

		//load the driver

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		//create connection
		String url="jdbc:oracle:thin:@10.125.6.62:1521:orcl11g";
		try(Connection con = DriverManager.getConnection(url, "labg104trg37", "labg104oracle")){
			
		if(con!=null){
			Statement st = con.createStatement();
			st.executeUpdate("delete from emp where job='manager'");
			System.out.println("inserted");
		}
			/*System.out.println("Connected");
				Statement st = con.createStatement();
				ResultSet rs = st.executeQuery("Select * from emp");
				
				while(rs.next()){
					int empno = rs.getInt(1);
					String f_name=rs.getString(2);
					System.out.println(empno+" "+f_name);
				}*/
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
