package com.JdbcProject.employee.api;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.JdbcProject.employee.util.JdbcUtil;

public class JdbcTest {

	public static void main(String[] args) {

Connection con=null;
PreparedStatement ps=null;
con= JdbcUtil.getConnection();
if(con!=null){
	System.out.println("Connected");
	String update= "update employees set employee_name=? where employee_code=?";
	
	try {
		ps=con.prepareStatement(update);
		ps.setString(1, "NamuGoru");
		ps.setInt(2, 101);
		int rec =ps.executeUpdate();
		System.out.println(rec);
	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



	}


}}