package com.cg2.eis.service;

import com.cg2.eis.bean.Employee;

public interface EmployeeService {

	public void getDetails(Employee emp);
	public void insuranceScheme(Employee emp);
	public void displayDetails(Employee emp);
	public void display(Employee emp,String insurance);
}
