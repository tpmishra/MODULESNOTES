package com.Lab11.ma.services;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.Lab11.ma.dao.IPurchaseDao;
import com.Lab11.ma.dao.PurchaseDaoImpl;
import com.Lab11.ma.dto.Purchase;
import com.Lab11.ma.exception.MobileException;



public class PurchaseServiceImpl implements IPurchaseService {
	IPurchaseDao ipd = new PurchaseDaoImpl();
	//Purchase p = new Purchase();

	
	public static boolean validateName(String patt,String name) throws MobileException{
	boolean value=Pattern.matches(patt,name);
	if(value){
		return true;
	}
	else{
		return false;
	}
	
	
	
	}
	
	public static boolean evalidateName(String patt,String name) throws MobileException{
	boolean value=Pattern.matches(patt,name);
	if(value){
		return true;
	}
	else{
		return false;
	}
		
	}
	
	public static boolean pvalidateName(String patt,String name) throws MobileException{
		boolean value=Pattern.matches(patt,name);
		if(value){
			return true;
		}
		else{
			return false;
		}
			
		}
	public static boolean mvalidateName(String patt,int mid) throws MobileException{
		Pattern mobileid=Pattern.compile(patt);
		Matcher mobileid1 = mobileid.matcher(String.valueOf(mid));
		if(mobileid1.matches()){
			return true;
		}
		else{
			return false;
		}
			
		}
	
	public static boolean dvalidateName(String patt,String name) throws MobileException{
		boolean value=Pattern.matches(patt,name);
		if(value){
			return true;
		}
		else{
			return false;
		}
			
		}

	public boolean addPurchaseDetail(Purchase purchase) throws MobileException {
		// TODO Auto-generated method stub
		//System.out.println(p.getcName());
		return ipd.insertPurchaseDetails(purchase);
	}

}
