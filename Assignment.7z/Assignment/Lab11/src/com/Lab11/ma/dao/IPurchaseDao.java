package com.Lab11.ma.dao;

import com.Lab11.ma.dto.Purchase;
import com.Lab11.ma.exception.MobileException;

public interface IPurchaseDao {

	public boolean insertPurchaseDetails(Purchase p) throws MobileException;
	
	
}
