package com.Lab5.Assign53;



public class TestBank {

	public static void main(String[] args) {
	
		
		Person smith = new Person("Smith",30);
		
		Person kathy = new Person("Kathy",20);
		
		//System.out.println(smith);
		WithDraw smithAcc = new WithDraw(2000);
		smithAcc.setAccHolder(smith);
		System.out.println(smithAcc);
		smithAcc.deposit(2000);
		
		
		
		//System.out.println(kathy);
		WithDraw kathyAcc = new WithDraw(3000);
		kathyAcc.setAccHolder(kathy);
		System.out.println(kathyAcc);
		kathyAcc.withdraw(2000);
		
		
		System.out.println("Updated balance of Smith: "+smithAcc.getBalance());
		System.out.println("Updated balance of Kathy: "+kathyAcc.getBalance());
		
	}

}
