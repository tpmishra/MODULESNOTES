package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeInsuranceSystem;
import com.cg.eis.service.EmployeeService;

public class InvokeFunctions {

	public static void main(String args[]) {

		
		Employee emp = new Employee();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter id: ");
		emp.setId(sc.nextInt());

		System.out.println("Enter name: ");
		emp.setName(sc.next());

		System.out.println("Enter salary: ");
		emp.setSalary(sc.nextInt());

		System.out
				.println("Enter designation as System Associate,Programmer,Manager,Clerk: ");
		emp.setDesignation(sc.next());

		EmployeeService es = new EmployeeInsuranceSystem();

		es.getDetails(emp);
		es.insuranceScheme(emp);
		es.displayDetails(emp);
		
		sc.close();

	}

}
