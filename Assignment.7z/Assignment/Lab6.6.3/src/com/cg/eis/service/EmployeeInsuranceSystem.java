package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public class EmployeeInsuranceSystem implements EmployeeService {

	int id, salary;
	String name, designation, insuranceScheme;


	public void getDetails(Employee emp) {

		this.id = emp.getId();
		this.name = emp.getName();
		this.salary = emp.getSalary();
		this.designation = emp.getDesignation();
	}


	public void insuranceScheme(Employee emp) {
		if (((salary > 5000) && (salary < 20000))
				&& (("System Associate".equals(designation)))) {
			emp.setInsuranceScheme("Scheme C");

		}

		else if (((salary >= 20000) && (salary < 40000))
				&& (("Programmer".equals(designation)))) {
			emp.setInsuranceScheme("Scheme B");
		} else if (((salary >= 40000)) && (("Manager".equals(designation)))) {
			emp.setInsuranceScheme("Scheme A");
		} else if (((emp.getSalary() < 5000))
				&& (("Clerk".equals(emp.getDesignation())))) {
			emp.setInsuranceScheme("No Scheme");
		}

	}


	public void displayDetails(Employee emp) {
		// TODO Auto-generated method stub

		System.out.println("ID: " + id);
		System.out.println("Name: " + name);
		System.out.println("Salary: " + salary);
		System.out.println("Designation: " + designation);
		System.out.println("Insurance Scheme: " + emp.getInsuranceScheme());
	}

}
