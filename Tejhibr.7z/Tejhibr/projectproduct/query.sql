select * from productdetails;

select productId_seq1.nextVal from dual

delete from productdetails

drop sequence productId_seqi;
create sequence productId_seqp start with 10000 increment by 1; 