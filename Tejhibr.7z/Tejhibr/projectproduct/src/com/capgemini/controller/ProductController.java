package com.capgemini.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.entity.Product;
import com.capgemini.service.IProductService;


@Controller
public class ProductController
{
	@Autowired
	IProductService productService;

	public ProductController() {
		super();
		// TODO Auto-generated constructor stub
	}

	public IProductService getProductService() {
		return productService;
	}

	public void setProductService(IProductService productService) {
		this.productService = productService;
	}

	public ProductController(IProductService productService) {
		super();
		this.productService = productService;
	}
	
	@RequestMapping("home")
	public String getHomePage()
	{
		return "HomePage";
	}
	
	@RequestMapping("addproduct")
	public String getAddProductPage(Model model)
	{
		//init the data for category drop down list
		List<String> categories = new ArrayList<>();
		categories.add("Shoes");
		categories.add("Electronics");
		categories.add("Clothes");
		categories.add("Book");
		categories.add("HomeTools");
		categories.add("Furniture");
		//Add the form backing bean to be binded to AddProduct.jsp form
		model.addAttribute("product", new Product());
		
		//Add categories to drop down list
		model.addAttribute("categories", categories);
		
		return "AddProductPage";
	
	
	}
	
	@RequestMapping(value="ProcessAddProductForm")
	public ModelAndView processAddProductForm(
			@ModelAttribute("product") @Valid Product product, BindingResult result
			,Model model)
	{
		
		if(result.hasErrors() == true)
		{
			List<String> categories = new ArrayList<>();
			categories.add("Shoes");
			categories.add("Electronics");
			categories.add("Clothes");
			categories.add("Book");
			categories.add("HomeTools");
			categories.add("Furniture");
			//Add the form backing bean to be binded to AddProduct.jsp form
			model.addAttribute("product", product);
			
			//Add categories to drop down list
			model.addAttribute("categories", categories);
			return new ModelAndView("AddProductPage");
		}
		int productId = -1;
		try{
			 productId = productService.addProduct(product);
			 model.addAttribute("message", "Product added Successfully with ProductId="+productId);
			return new ModelAndView("SuccessPage");
		}
		catch(Exception e)
		{
			
			model.addAttribute("errMsg", "Could not add Producrt");
		
		return new ModelAndView("ErrorPage");
		}
	}
	@RequestMapping("getproduct")
	public String getProductPage()
	{
		return "GetProductPage";
		
	}
	@RequestMapping("processgetproductform")
	public ModelAndView processGetProductForm(@RequestParam("productId") int pid)
	{
		Product product = null;
		try
		{
			product = productService.getProduct(pid);
			return new ModelAndView("GetProductPage","product",product);
		}
		catch(Exception e)
		{
			return new ModelAndView("ErrorPage","errMsg","Could not retrieve the product Reason:"+e.getMessage());
		}
	}
	
	@RequestMapping("viewallproducts")
	public String getViewAllProducts(Model model)
	{
		List<Product> products = null;
		try
		{
			products = productService.getAllProducts();
			model.addAttribute("products", products);
		}
		catch(Exception E)
		{
			model.addAttribute("errMsg", "Could not display the product Reason:"+E.getMessage());
			return "ErrorPage";
		}
		return "ViewAllProductsPage";
		
	}
	@RequestMapping("getupdatepage")
	public String getUpdatePage(@RequestParam("pid") int id,Model model)
	{
		List<String> categories = new ArrayList<>();
		categories.add("Shoes");
		categories.add("Electronics");
		categories.add("Clothes");
		categories.add("Book");
		categories.add("HomeTools");
		categories.add("Furniture");
		
		Product product = null;
		try{
			product = productService.getProduct(id);
		}
		catch(Exception e)
		{
			model.addAttribute("errMsg", "Could not retrieve Product Details Reason:"+e.getMessage());
			return "ErrorPage";
		}
		//Add the form backing bean to be binded to AddProduct.jsp form
		model.addAttribute("product", product);
		
		//Add categories to drop down list
		model.addAttribute("categories", categories);
		
		return "UpdatePage";
		
	}
	
	
	@RequestMapping(value="ProcessupdatepageForm",method=RequestMethod.POST)
	public String ProcessUpdatePageForm(@ModelAttribute("product") @Valid
			Product product,BindingResult result, Model model)
	{

		if(result.hasErrors() == true)
		{
			List<String> categories = new ArrayList<>();
			categories.add("Shoes");
			categories.add("Electronics");
			categories.add("Clothes");
			categories.add("Book");
			categories.add("HomeTools");
			categories.add("Furniture");
			//Add the form backing bean to be binded to AddProduct.jsp form
			model.addAttribute("product", product);
			
			//Add categories to drop down list
			model.addAttribute("categories", categories);
			return "UpdatePage";
		}
		
		try
		{
			productService.updateProduct(product);
		}
		catch(Exception e)
		{
			model.addAttribute("errMsg", "Could not update Product Details Reason:"+e.getMessage());
			return "ErrorPage";
		}
		model.addAttribute("message", "Product Updated Successfully");
		return "SuccessPage";
	}
}

















