package com.capgemini.gym.dao;

import java.util.List;

import com.capgemini.gym.entities.Customer;
import com.capgemini.gym.exception.BookingException;

public interface IBookingDAO 
{
	public int addCustomer(Customer customer) throws BookingException;
	public Customer getCustomer(int id ) throws BookingException ;
	public void updateCustomer(Customer customer) throws BookingException ;
	public List<Customer> getAllCustomers() throws BookingException ;
	public void deleteCustomer(int id ) throws BookingException ;
}
