CREATE TABLE employee(employee_code NUMBER PRIMARY KEY,employee_name VARCHAR2(50),
employee_gender VARCHAR(10),designation_name VARCHAR2(30),employee_email VARCHAR2(30),
employee_phone NUMBER(10));   

DROP TABLE EMPLOYEE;

SELECT * FROM EMPLOYEE;

CREATE SEQUENCE hibernate_sequence;

DROP SEQUENCE hibernate_sequence;

COMMIT;

select hibernate_sequence from dual;