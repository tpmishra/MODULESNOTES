package com.capgemini.eda.dao;

import java.util.List;

import com.capgemini.eda.entity.Employee;
import com.capgemini.eda.exception.EmployeeException;



public interface IEmployeeDAO {
	public int  addEmployee(Employee employee) throws EmployeeException;
	public List<Employee> getAllEmployees() throws EmployeeException;
}
