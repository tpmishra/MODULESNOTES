package com.capgemini.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.capgemini.bean.Employee;
import com.capgemini.exception.EmployeeException;


@Repository("employeeDAO")
public class EmployeeDaoImpl implements IEmployeeDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	
	public EmployeeDaoImpl() {
		
	}

	public EmployeeDaoImpl(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	
	/*******************************
	 * Author : TejPrakashMishra
	 * method :	addEmployee
	 * returnType:Integer
	 *********************************/
	@Override
	public int addEmployee(Employee employee1) throws EmployeeException {
		int EmployeeId = 0;
		try
		{
			
			
			
			entityManager.persist(employee1);
			
			EmployeeId = employee1.getEmployee_code();
			
				
		}
		catch(Exception e)
		{
			
			
			
			throw new EmployeeException(e.getMessage());
		}
		return EmployeeId;
	}
	

	/**********************************
	 * Author : TejPrakashMishra
	 * MethodName :	getAllEmployees
	 * returnType:Employee
	 ***********************************/
	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		List<Employee> employee1 = new ArrayList<Employee>();
		try
		{
			employee1 = entityManager.createQuery("from Employee").getResultList();
		}
	
	catch(Exception e)
	{
		throw new EmployeeException(e.getMessage());
	}
		if(employee1 == null  || employee1.isEmpty() )
			throw new EmployeeException("No Employee to display");
		
		return employee1;
	}
	}


