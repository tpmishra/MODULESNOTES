package com.capgemini.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bean.Employee;
import com.capgemini.dao.IEmployeeDao;
import com.capgemini.exception.EmployeeException;

@Transactional
@Service("employeeService")
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	private IEmployeeDao employeeDAO;
	
	public IEmployeeDao getEmployeeDAO() {
		return employeeDAO;
	}

	public void setEmployeeDAO(IEmployeeDao employeeDAO) {
		this.employeeDAO = employeeDAO;
	}
		public EmployeeServiceImpl() {
		
	}

	public EmployeeServiceImpl(IEmployeeDao employeeDAO) {
		super();
		this.employeeDAO = employeeDAO;
	}


	
	@Override
	public int addEmployee(Employee employee1) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDAO.addEmployee(employee1);
	}

	

	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDAO.getAllEmployees();
	}

}
