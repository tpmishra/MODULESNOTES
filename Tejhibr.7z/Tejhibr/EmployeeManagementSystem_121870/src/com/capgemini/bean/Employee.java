package com.capgemini.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name="employee")
public class Employee {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "mysequence123")
	@SequenceGenerator(name="mysequence123",sequenceName="hibernate_sequence", initialValue = 1000)
	@Column(name="employee_code")
	private int employee_code;
	
	
	@NotEmpty(message = "Name Cannot be Empty")

	@Size(min=3,max=40, message = "Size cn be maximum 40 characters long")
	@Column(name="employee_name",nullable=false)
	private String employee_name;
	
	
	@NotEmpty(message="Gender should be selected ")
	@Column(name="employee_gender",nullable=false)
	private String employee_gender;
	
	@NotEmpty(message="Designation name should be selected")
	@Column(name="designation_name",nullable=false)
	private String designation_name;
	
	@NotEmpty(message="Email should be selected")
	@Email(message="Please enter valid Email ID")
	@Column(name="employee_email",nullable=false)
	private String employee_email;
	
	@Column(name="employee_phone",nullable=false)
	private long employee_phone;
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + employee_code;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (employee_code != other.employee_code)
			return false;
		return true;
	}
	public Employee(String employee_name, String employee_gender,
			String designation_name, String employee_email, long employee_phone) {
		super();
		this.employee_name = employee_name;
		this.employee_gender = employee_gender;
		this.designation_name = designation_name;
		this.employee_email = employee_email;
		this.employee_phone = employee_phone;
	}
	@Override
	public String toString() {
		return "Employee [employee_code=" + employee_code + ", employee_name="
				+ employee_name + ", employee_gender=" + employee_gender
				+ ", designation_name=" + designation_name
				+ ", employee_email=" + employee_email + ", employee_phone="
				+ employee_phone + "]";
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int employee_code, String employee_name,
			String employee_gender, String designation_name,
			String employee_email, long employee_phone) {
		super();
		this.employee_code = employee_code;
		this.employee_name = employee_name;
		this.employee_gender = employee_gender;
		this.designation_name = designation_name;
		this.employee_email = employee_email;
		this.employee_phone = employee_phone;
	}
	public int getEmployee_code() {
		return employee_code;
	}
	public void setEmployee_code(int employee_code) {
		this.employee_code = employee_code;
	}
	public String getEmployee_name() {
		return employee_name;
	}
	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}
	public String getEmployee_gender() {
		return employee_gender;
	}
	public void setEmployee_gender(String employee_gender) {
		this.employee_gender = employee_gender;
	}
	public String getDesignation_name() {
		return designation_name;
	}
	public void setDesignation_name(String designation_name) {
		this.designation_name = designation_name;
	}
	public String getEmployee_email() {
		return employee_email;
	}
	public void setEmployee_email(String employee_email) {
		this.employee_email = employee_email;
	}
	public long getEmployee_phone() {
		return employee_phone;
	}
	public void setEmployee_phone(long employee_phone) {
		this.employee_phone = employee_phone;
	}

}
