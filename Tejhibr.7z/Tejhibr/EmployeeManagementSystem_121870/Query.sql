

create table employee(employee_code number primary key,employee_name varchar2(60),
employee_gender varchar(10),designation_name varchar2(30),employee_email varchar2(30),
employee_phone number(10)


);
drop table employee;
delete from employee
select * from EMPLOYEE
drop sequence hibernate_sequence

create SEQUENCE hibernate_sequence start with 1000 increment by 1;