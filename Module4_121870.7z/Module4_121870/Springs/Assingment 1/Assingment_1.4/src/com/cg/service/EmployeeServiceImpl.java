package com.cg.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.beans.Employee;


@Component("productService")
public class EmployeeServiceImpl implements IEmployeeService 
{

	@Override
	public List<Employee> getEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

}
