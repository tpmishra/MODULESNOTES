package com.cg.service;

import java.util.List;

import com.cg.beans.Employee;

public interface IEmployeeService
{
	public List<Employee> getEmployee() ;
}
