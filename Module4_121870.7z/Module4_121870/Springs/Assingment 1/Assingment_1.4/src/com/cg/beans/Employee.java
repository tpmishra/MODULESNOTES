package com.cg.beans;

import org.springframework.stereotype.Component;


@Component
public class Employee 
{
	private int employeeId;
	private String name;
	private String Salary;
	public Employee(int employeeId, String name, String salary) {
		this.employeeId = employeeId;
		this.name = name;
		Salary = salary;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSalary() {
		return Salary;
	}
	public void setSalary(String salary) {
		Salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", name=" + name
				+ ", Salary=" + Salary + "]";
	}
	
	
}
