package com.cg.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.cg.beans.Employee;

@Component("productDao")
public class EmployeeDAOImpl implements IEmployeeDAO 
{
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}




	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public EmployeeDAOImpl() {
		super();
		// TODO Auto-generated constructor stub
	}




	@Override
	public List<Employee> getEmployee() 
	{
		
		return null;
	}
	
}
