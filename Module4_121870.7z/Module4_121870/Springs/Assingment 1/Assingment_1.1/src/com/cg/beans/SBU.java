package com.cg.beans;

import java.io.Serializable;

public class SBU implements Serializable 
{
	private int sbuId;
	private String name;
	private String sbuHead;
	public SBU(int sbuId, String name, String sbuHead) {
		this.sbuId = sbuId;
		this.name = name;
		this.sbuHead = sbuHead;
	}
	public SBU() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getSbuId() {
		return sbuId;
	}
	public void setSbuId(int sbuId) {
		this.sbuId = sbuId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	@Override
	public String toString() {
		return "SBU [sbuId=" + sbuId + ", name=" + name + ", sbuHead="
				+ sbuHead + "]";
	}
	
	
}
