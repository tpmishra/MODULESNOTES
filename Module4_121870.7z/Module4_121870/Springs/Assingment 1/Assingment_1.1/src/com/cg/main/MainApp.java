package com.cg.main;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.beans.Employee;

public class MainApp 
{
	public static void main(String[] args) 
	
	{
		Resource res = new ClassPathResource("spring.xml");
		
		BeanFactory factory = new XmlBeanFactory(res);
		
		Employee emp = factory.getBean("empp",Employee.class);
		
		
		System.out.println("Employee Details");

		System.out.println("--------------------------------------------------");
		
		System.out.println("EmployeeId : "+emp.getId());
		System.out.println("EmployeeName : "+emp.getName());
		System.out.println("Salary : "+emp.getSalary());
		System.out.println("Emplotyee BU : "+emp.getBusinessUnit());
		System.out.println("Employee Age : "+emp.getAge());
	}
}
