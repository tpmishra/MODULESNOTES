CREATE table Trainee(traineeId number primary key, traineeName varchar2(10), traineeDomain varchar2(10), traineeLocation varchar2(10));

CREATE SEQUENCE Trainee_Seq start with 1000;

select * from Trainee;
drop table trainee




