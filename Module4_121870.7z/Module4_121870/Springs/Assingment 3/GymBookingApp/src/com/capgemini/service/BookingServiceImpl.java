package com.capgemini.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.IBookingDAO;
import com.capgemini.entities.Customer;
import com.capgemini.exception.BookingException;

@Service
@Transactional
public class BookingServiceImpl implements IBookingService

{
	@Autowired
	private IBookingDAO bookingDAO;

	public BookingServiceImpl(IBookingDAO bbokingDAO) {
		super();
		this.bookingDAO = bbokingDAO;
	}

	public BookingServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public IBookingDAO getBbokingDAO() {
		return bookingDAO;
	}

	public void setBbokingDAO(IBookingDAO bbokingDAO) {
		this.bookingDAO = bbokingDAO;
	}

	@Override
	public int addCustomer(Customer customer) throws BookingException {
		// TODO Auto-generated method stub
		return bookingDAO.addCustomer(customer);
	}

	@Override
	public Customer getCustomer(int id) throws BookingException {
		// TODO Auto-generated method stub
		return bookingDAO.getCustomer(id);
	}

	@Override
	public void updateCustomer(Customer customer) throws BookingException {
	
		
	}
	
	
}
