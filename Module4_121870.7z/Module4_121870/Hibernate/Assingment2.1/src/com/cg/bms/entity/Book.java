package com.cg.bms.entity;

public class Book 
{
	private String ISBN;
	private String title;
	private double price;
	public Book(String iSBN, String title, double price) {
		ISBN = iSBN;
		this.title = title;
		this.price = price;
	}
	public String getISBN() {
		return ISBN;
	}
	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Book [ISBN=" + ISBN + ", title=" + title + ", price=" + price
				+ "]";
	}
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
