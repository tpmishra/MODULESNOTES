package com.cg.bms.entity;

public class Book_author 

{
	private String book;
	private String author;
	public Book_author(String book, String author) {
		this.book = book;
		this.author = author;
	}
	public String getBook() {
		return book;
	}
	public void setBook(String book) {
		this.book = book;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	@Override
	public String toString() {
		return "Book_author [book=" + book + ", author=" + author + "]";
	}
	public Book_author() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
