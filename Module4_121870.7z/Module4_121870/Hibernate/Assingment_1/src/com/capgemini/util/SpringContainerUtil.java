package com.capgemini.util;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringContainerUtil 
{
	static ApplicationContext context = null;
	
	public static ApplicationContext getApplicationContext()
	{
		if (context == null)
			context = new ClassPathXmlApplicationContext("spring.xml");
		
		return context;
	}
}
