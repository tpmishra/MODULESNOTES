package com.capgemini.test;

import com.capgemini.entities.Product;
import com.capgemini.service.IProductService;
import com.capgemini.service.ProductServiceImpl;

public class TestProductManual {

	
	
	public static void main(String main[]) {
		
		IProductService service=new ProductServiceImpl();
		Product product=new Product("HTC Phone",10,35000);
		int id=service.addProduct(product);
		System.out.println(id);
		
		Product p1=service.getProduct(2);
		System.out.println(p1);
	
		Product p2=new Product(2,"Smart Watch",20,3000);
		service.updateProduct(p2);
		System.out.println(p2);
		
			service.removeProduct(5);
		
		
	}
}
