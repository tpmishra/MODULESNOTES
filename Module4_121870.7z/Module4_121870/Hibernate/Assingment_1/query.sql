select * from productdetails; 

delete from productdetails; 