package com.capgemini.service;

import java.util.List;




import com.capgemini.dao.IProductDao;
import com.capgemini.dao.ProductDaoImpl;
import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;

public class ProductServiceImpl implements IProductService{

	private IProductDao productDao;
	public ProductServiceImpl() {
		productDao=new ProductDaoImpl();
	}	


	
	@Override
	public int addProduct(Product product) throws ProductException {		
	return productDao.addProduct(product);
}

	@Override
	public void updateProduct(Product product) throws ProductException {
		
		productDao.updateProduct(product);
	}

	@Override
	public Product getProduct(int id) throws ProductException {
		
	
		return productDao.getProduct(id);
	}

	@Override
	public void removeProduct(int id) throws ProductException {
		
		productDao.removeProduct(id);
		
	}


	@Override
	public List<Product> getAllProducts() throws ProductException {

		return productDao.getAllProducts();
	}


	@Override
	public Product getProductByName(String name) throws ProductException {
	
		return productDao.getProductByName(name);
	}


	@Override
	public List<Product> getProductsByRange(float min, float max)
			throws ProductException {

		return productDao.getProductsByRange(min, max);
	}

}
