package com.capgemini.publisher;

import javax.xml.ws.Endpoint;

import com.capgemini.ws.IProductService;
import com.capgemini.ws.ProductServiceImpl;

public class ServicePublisher {

	public static void main(String[] args) {
		
		
		IProductService services=new ProductServiceImpl();

		Endpoint.publish("http://localhost:9995/products", services);
		System.out.println("Products services are published");
		
	}

}
