package com.cg.ems.service;

import java.util.List;

import com.cg.ems.bean.Employee;
import com.cg.ems.dao.EmployeeDAOImpl;
import com.cg.ems.dao.IEmployeeDAO;
import com.cg.ems.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService 
{
	IEmployeeDAO employeeDAO ;
	
	public EmployeeServiceImpl() 
	{
		employeeDAO = new EmployeeDAOImpl() ;
	}

	@Override
	public Employee getEmployee(int empno) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDAO.getEmployee(empno);
	}

	@Override
	public List<Employee> getEmployeeByName(String name)
			throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDAO.getEmployeeByName(name);
	}

	@Override
	public List<Employee> getEmployeeByDeptNo(int deptno)
			throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDAO.getEmployeeByDeptNo(deptno);
	}

	@Override
	public List<Employee> getEmployeeByLocation(String location)
			throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDAO.getEmployeeByLocation(location);
	}

}
