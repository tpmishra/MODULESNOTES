package com.cg.ems.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import com.cg.ems.bean.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUtil;

public class EmployeeDAOImpl implements IEmployeeDAO 
{

	Connection con ;
	Statement stm ;
	PreparedStatement pstm ;
	ResultSet res ;
	@Override
	public Employee getEmployee(int empno) throws EmployeeException 
	{
		Employee employee = null ;
		try
		{
			con = DBUtil.getConnection() ;
			pstm = con.prepareCall("select * from employee_master where emp_num=?") ;
			pstm.setInt(1, empno);
			res = pstm.executeQuery();
			res.next();
			employee = new Employee() ;
			employee.setEmpno(res.getInt(1));
			employee.setEmpname(res.getString(2));
			employee.setDeptno(res.getInt(3));
			employee.setSalary(res.getDouble(4));
			employee.setLocation(res.getString(5));
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return employee;
	}
	@Override
	public List<Employee> getEmployeeByName(String name)
			throws EmployeeException {
		List<Employee> empList = new ArrayList<Employee>() ;
		Employee employee = null ;
		try
		{
			con = DBUtil.getConnection();
			pstm = con.prepareStatement("select * from employee_master where emp_name=?") ;
			pstm.setString(1, name);
			res = pstm.executeQuery();
			while(res.next())
			{
				employee = new Employee();
				employee.setEmpno(res.getInt(1));
				employee.setEmpname(res.getString(2));
				employee.setDeptno(res.getInt(3));
				employee.setSalary(res.getDouble(4));
				employee.setLocation(res.getString(5));
				empList.add(employee);
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return empList;
	}
	@Override
	public List<Employee> getEmployeeByDeptNo(int deptno)
			throws EmployeeException {
		List<Employee> empList = new ArrayList<Employee>() ;
		Employee employee = null ;
		try
		{
			con = DBUtil.getConnection();
			pstm = con.prepareStatement("select * from employee_master where dept_num=?") ;
			pstm.setInt(1, deptno);
			res = pstm.executeQuery();
			while(res.next())
			{
				employee = new Employee();
				employee.setEmpno(res.getInt(1));
				employee.setEmpname(res.getString(2));
				employee.setDeptno(res.getInt(3));
				employee.setSalary(res.getDouble(4));
				employee.setLocation(res.getString(5));
				empList.add(employee);
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return empList;
	}
	@Override
	public List<Employee> getEmployeeByLocation(String location)
			throws EmployeeException {
		List<Employee> empList = new ArrayList<Employee>() ;
		Employee employee = null ;
		try
		{
			con = DBUtil.getConnection();
			pstm = con.prepareStatement("select * from employee_master where location=?") ;
			pstm.setString(1, location);
			res = pstm.executeQuery();
			while(res.next())
			{
				employee = new Employee();
				employee.setEmpno(res.getInt(1));
				employee.setEmpname(res.getString(2));
				employee.setDeptno(res.getInt(3));
				employee.setSalary(res.getDouble(4));
				employee.setLocation(res.getString(5));
				empList.add(employee);
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return empList;
	}

}
