package com.cg.ems.bean;

public class Employee 
{
	private int empno ;
	private String empname ;
	private int deptno ;
	private double salary ;
	private String location ;
	
	public Employee(int empno, String empname, int deptno, double salary,
			String location) {
		super();
		this.empno = empno;
		this.empname = empname;
		this.deptno = deptno;
		this.salary = salary;
		this.location = location;
	}
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public int getDeptno() {
		return deptno;
	}

	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "Employee [empno=" + empno + ", empname=" + empname
				+ ", deptno=" + deptno + ", salary=" + salary + ", location="
				+ location + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + empno;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (empno != other.empno)
			return false;
		return true;
	}
	
	
}
