package com.cg.ems.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ems.bean.Employee;
import com.cg.ems.service.EmployeeServiceImpl;
import com.cg.ems.service.IEmployeeService;
import com.oracle.jrockit.jfr.RequestDelegate;

@WebServlet("/search")
public class EmployeeController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	IEmployeeService empService ;

    public EmployeeController() 
    {
        super();
        empService = new EmployeeServiceImpl();
    }

	public void init(ServletConfig config) throws ServletException 
	{
		
	}

	public void destroy() 
	{
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String path = request.getServletPath() ;
		String url ="" ;
		System.out.println(path);
		switch (path) 
		{
			case "/search":
				String emp = request.getParameter("emp") ;
				System.out.println(emp);
				String empValue = request.getParameter("empValue");
				System.out.println(empValue);
				if(emp.equals("emp_num"))
				{
					int empno = Integer.parseInt(empValue);
					Employee employee = empService.getEmployee(empno);
					request.setAttribute("employee", employee);
					url="InfoByID.jsp" ;
				}
				
				if(emp.equals("emp_name"))
				{
					String name =empValue ;
					List<Employee> empList = empService.getEmployeeByName(name);
					request.setAttribute("empList", empList);
					System.out.println(empList);
					url="Find_Data.jsp";
					
				}
				
				if(emp.equals("dept_num"))
				{
					int deptno =Integer.parseInt(empValue) ;
					List<Employee> empList = empService.getEmployeeByDeptNo(deptno);
					request.setAttribute("empList", empList);
					System.out.println(empList);
					url="Find_Data.jsp";
					
				}
				
				if(emp.equals("location"))
				{
					String location = empValue ;
					List<Employee> empList = empService.getEmployeeByLocation(location);
					request.setAttribute("empList", empList);
					System.out.println(empList);
					url="Find_Data.jsp";
					
				}
				break;

		default:
			break;
		}
		
		RequestDispatcher rd = request.getRequestDispatcher(url);
		rd.forward(request, response);
	}

}
