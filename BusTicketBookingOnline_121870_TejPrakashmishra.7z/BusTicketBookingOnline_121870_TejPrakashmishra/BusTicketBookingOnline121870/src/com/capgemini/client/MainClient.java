package com.capgemini.client;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.service.BusService;
import com.capgemini.service.BusServiceImpl;



public class MainClient {
	private BusService busService;
	public MainClient()
	{
		busService  = new BusServiceImpl(); 
	}
	

	public static void main(String[] args) {
		MainClient emsUI = new MainClient();
		while(true)
		{
			emsUI.showMenu();
		}

	}
	public void showMenu()
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("1.BOOK TICKET");
		System.out.println("2.Exit");
		
	int choice = scanner.nextInt();
	switch(choice)
	{
	case 1: viewTicket();  break;
	case 2: 
		System.out.println("Thank You ! Exiting Application");
		System.exit(0);
	break;
	default:
		System.out.println("Invalid Input");
	break;
	}
	
	
	}


	private void viewTicket() {
		try
		{
			List<BusBean> BusDetails = busService.retrieveBusDetails();
			
			Iterator<BusBean> it =BusDetails.iterator();
			System.out.println("busId \tbusType \tFromStop \tToStop \tAvailableSeats \tFare \tDate of journey");
			while(it.hasNext())
			{
				BusBean bean = it.next();
				System.out.println(bean.getBusId()+"\t"
						        +bean.getBusType()+"\t"
								+bean.getFromStop()+"\t\t"
								+bean.getToStop()+"\t"
								+bean.getAvailableSeats()+"\t\t"
								+bean.getFare()+"\t"
								+bean.getDateOfJourney());
			
				
				
				
				
			}
			
		}
			
		catch(BookingException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
			
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Customer id");
		String custId = scanner.next();
		System.out.println("Enter bus id");
		int busId = scanner.nextInt();
		System.out.println("Enter no of seats");
		int noOfSeat = scanner.nextInt();
		BookingBean bean = new BookingBean();
		bean.setCustId(custId);
		bean.setBusId(busId);
		bean.setNoOfSeat(noOfSeat);
		try
		{
			int bookingId = busService.bookTicket(bean);
			System.out.println("Thank you. Your bookingn  Id is"+bookingId);
		}
		catch(BookingException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
		
	

}
