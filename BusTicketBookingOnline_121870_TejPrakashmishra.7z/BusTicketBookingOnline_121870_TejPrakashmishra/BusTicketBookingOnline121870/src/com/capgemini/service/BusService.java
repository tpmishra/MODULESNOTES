package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;

public interface BusService {
	
	public ArrayList<BusBean>retrieveBusDetails() throws BookingException;
	public int bookTicket(BookingBean bookingbean) throws BookingException;


}
