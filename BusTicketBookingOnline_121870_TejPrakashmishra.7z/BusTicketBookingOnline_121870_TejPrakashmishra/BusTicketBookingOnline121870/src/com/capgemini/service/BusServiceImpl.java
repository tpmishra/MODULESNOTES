package com.capgemini.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;




public class BusServiceImpl implements BusService {
	private BusDao busDao;
	public BusServiceImpl()
	{
		busDao = new BusDaoImpl();
	
		
	}
	/*private IEmployeeDAO employeeDAO;
	
	 public EmployeeServiceImpl() {
		// TODO Auto-generated constructor stub
		employeeDAO = new EmployeeDAOImpl();
	}*/
	

	@Override
	public ArrayList<BusBean> retrieveBusDetails() throws BookingException {
		// TODO Auto-generated method stub
		return busDao.retrieveBusDetails();
	}

	@Override
	public int bookTicket(BookingBean bookingbean) throws BookingException {
		// TODO Auto-generated method stub
		return busDao.bookTicket(bookingbean);
	}

}

/*public List<Player> getPlayers() throws EmployeeException {
	// TODO Auto-generated method stub
	return playerDAO.getPlayers();
}
*/