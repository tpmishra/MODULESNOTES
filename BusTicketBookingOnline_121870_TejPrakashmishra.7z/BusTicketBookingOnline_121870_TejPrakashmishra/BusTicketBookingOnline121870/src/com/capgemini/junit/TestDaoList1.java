package com.capgemini.junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.bean.BookingBean;
import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;

public class TestDaoList1 {
	 BusDao busService;
		BookingBean busdetails;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		busService = new BusDaoImpl();
		busdetails = new BookingBean();
	}

	@After
	public void tearDown() throws Exception {
		busService = null;
	}

	@Test
	public void testBookTicket() {
		assertNotNull(busdetails);
	}

}
