package com.capgemini.bean;

public class BookingBean {
	private int bookingId;
	private int noOfSeat;
	private int busId;
	private String custId;
	public BookingBean(int bookingId, int noOfSeat, int busId, String custId) {
		super();
		this.bookingId = bookingId;
		this.noOfSeat = noOfSeat;
		this.busId = busId;
		this.custId = custId;
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public int getNoOfSeat() {
		return noOfSeat;
	}
	public void setNoOfSeat(int noOfSeat) {
		this.noOfSeat = noOfSeat;
	}
	public int getBusId() {
		return busId;
	}
	public void setBusId(int busId) {
		this.busId = busId;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public BookingBean() {
		super();
	}
	@Override
	public String toString() {
		return "BookingBean [bookingId=" + bookingId + ", noOfSeat=" + noOfSeat
				+ ", busId=" + busId + ", custId=" + custId + "]";
	}

}
