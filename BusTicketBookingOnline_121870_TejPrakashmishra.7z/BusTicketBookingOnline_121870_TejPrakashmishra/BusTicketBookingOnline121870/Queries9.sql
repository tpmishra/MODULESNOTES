
create table BusDetails(busId NUMBER PRIMARY KEY, busTYPE VARCHAR(20),fromStop varchar(20),toStop varchar(20),fare DECIMAL,availableseats NUMBER,dateOfJourney)

CREATE TABLE BusDetails(busId NUMBER PRIMARY KEY, busType VARCHAR(20), fromStop VARCHAR(20),toStop VARCHAR(20),fare DECIMAL, availableSeats NUMBER, dateOfJourney DATE);
INSERT INTO BusDetails VALUES (1,'ac-neeta','Mumbai','Pune',420,30,'19-Nov-14');
INSERT INTO BusDetails VALUES (2,'shivneri','Pune','Mumbai',420,30,'19-Nov-14');
INSERT INTO BusDetails VALUES (3,'shivneri','Mumbai','Chennai',1000,30,'20-Nov-14');
INSERT INTO BusDetails VALUES (4,'ac-neeta','Mumbai','Chennai',1000,30,'20-Nov-14');
select * from BusDetails;
CREATE TABLE BookingDetails(bookingId NUMBER PRIMARY KEY,custId VARCHAR2(10),busId REFERENCES BusDetails(busId),noOfSeats Number);
CREATE SEQUENCE Booking_Id_Seq start with 1001;
select * from BookingDetails;