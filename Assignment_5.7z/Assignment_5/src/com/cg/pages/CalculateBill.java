package com.cg.pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.BillDetails;
import com.cg.service.BillServiceImpl;
import com.cg.service.IBillService;

@WebServlet("/CalculateBill")
public class CalculateBill extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	int FIXED_CHARGE = 100 ;
	BillDetails billDetails ;
	IBillService billService ;
    public CalculateBill() 
    {
        super();
        billService = new BillServiceImpl() ;
    }

	public void init(ServletConfig config) throws ServletException 
	{
		
	}

	public void destroy() 
	{
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String consNum = (String) request.getAttribute("conNum") ;
		String lmr = (String) request.getAttribute("lastMR") ;
		String cmr = (String) request.getAttribute("currentMR") ;
		
		int consNumber = Integer.parseInt(consNum) ;
		int lastMR = Integer.parseInt(lmr) ;
		int currentMR = Integer.parseInt(cmr) ;
		
		if(currentMR > lastMR)
		{
			int unitConsumed = currentMR - lastMR ;
			double netamount = unitConsumed * 1.15 + FIXED_CHARGE ;
			billDetails = new BillDetails() ;
			billDetails.setConsumernum(consNumber);
			billDetails.setCurrentreading(currentMR);
			billDetails.setUnitConsumed(unitConsumed);
			billDetails.setNetamount(netamount);
			Long millis = System.currentTimeMillis() ;
			java.sql.Date date = new Date(millis) ;
			billDetails.setBill_date(date);
			
			billService.addBillDetails(billDetails) ;
			
			
		}
		else
		{
			PrintWriter out = response.getWriter() ;
			out.println("Current Meter Reading Should be greater than Last Month Meter Reading");
		}
	}

}
