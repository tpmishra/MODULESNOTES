package com.cg.bean;

import java.sql.Date;


public class BillDetails 
{
	private int billnumber ;
	private int consumernum ;
	private int currentreading ;
	private int unitConsumed ;
	private  double netamount ;
	private Date bill_date ;
	
	public BillDetails(int billnumber, int consumernum, int currentreading,
			int unitConsumed, double netamount, Date bill_date) {
		super();
		this.billnumber = billnumber;
		this.consumernum = consumernum;
		this.currentreading = currentreading;
		this.unitConsumed = unitConsumed;
		this.netamount = netamount;
		this.bill_date = bill_date;
	} 
	
	public BillDetails() {
		// TODO Auto-generated constructor stub
	}

	public int getBillnumber() {
		return billnumber;
	}

	public void setBillnumber(int billnumber) {
		this.billnumber = billnumber;
	}

	public int getConsumernum() {
		return consumernum;
	}

	public void setConsumernum(int consumernum) {
		this.consumernum = consumernum;
	}

	public int getCurrentreading() {
		return currentreading;
	}

	public void setCurrentreading(int currentreading) {
		this.currentreading = currentreading;
	}

	public int getUnitConsumed() {
		return unitConsumed;
	}

	public void setUnitConsumed(int unitConsumed) {
		this.unitConsumed = unitConsumed;
	}

	public double getNetamount() {
		return netamount;
	}

	public void setNetamount(double netamount) {
		this.netamount = netamount;
	}

	public Date getBill_date() {
		return bill_date;
	}

	public void setBill_date(Date bill_date) {
		this.bill_date = bill_date;
	}

	@Override
	public String toString() {
		return "BillDetails [billnumber=" + billnumber + ", consumernum="
				+ consumernum + ", currentreading=" + currentreading
				+ ", unitConsumed=" + unitConsumed + ", netamount=" + netamount
				+ ", bill_date=" + bill_date + "]";
	}
	
	
}
