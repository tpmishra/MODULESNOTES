package com.capgemini.core.ems.view;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.core.ems.bean.Employee;
import com.capgemini.core.ems.service.EmployeeServiceImpl;
import com.capgemini.core.ems.service.IEmployeeService;

import core.caogemini.core.ems.exception.EmployeeException;

public class EmployeeView {
	private IEmployeeService employeeService;
	public EmployeeView()
	{
		employeeService = new EmployeeServiceImpl();
	}
	public static void main(String[] args)

	{
		EmployeeView emsUI = new EmployeeView();
		while(true)
		{
		emsUI.showMenu();
		}
	}
	public void showMenu()
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("1) ADD Employee");
		System.out.println("2) GET Employee");
		System.out.println("3) Update Employee");
		System.out.println("4) Remove Employee");
		System.out.println("5) View All Employee");
		System.out.println("6) Exit Application");
		System.out.println("iNSERT YOUR CHOICE");
		int choice = scanner.nextInt();
		
		switch(choice)
		{
		case 1:addEmployee();   	break;
		case 2:getEmployee();   	break;
		case 3:updateEmployee();   	break;
		case 4:removeEmployee();   	break;
		case 5:viewEmployee();   	break;
		case 6: 
			System.out.println("Thank You ! Exiting Application");
			System.exit(0);
		break;
		default:
			System.out.println("Invalid Input");
		break;
		}
}

	
	private void addEmployee() 
	{
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Provide employee Information");
		
		System.out.println("Employee Name");
		String name = scanner.next();
		
		System.out.println("Employee Department");
		String dept = scanner.next();
		
		System.out.println("Employee Designation");
		String desg = scanner.next();
		
		System.out.println("Employee Salary");
		float salary = scanner.nextFloat();
		
		Employee employee = new Employee();
		employee.setName(name);
		employee.setDepartment(dept);
		employee.setDesignation(desg);
		employee.setSalary(salary);
		
		//send emp obj to database via service
		
		
		try
		{
			int id = employeeService.addEmployee(employee);
			System.out.println("Employee added successfully with id"+id);
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	private void getEmployee() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Retriving Employee Information");
		System.out.println("\nEmployee Id");
		int id=scanner.nextInt();
		try
		{
			Employee employee = employeeService.getEmployee(id);
			System.out.println("\n**Employee Information**");
			System.out.println("ID:"  + employee.getId());
			System.out.println("Name:" + employee.getName());
			System.out.println("Department"  + employee.getDepartment());
			System.out.println("Designation"+ employee.getDesignation());
			System.out.println("Salary" + employee.getSalary());
			System.out.println("\n\n");
			
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	private void updateEmployee() 
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("Updating Employee Information");
		System.out.println("\n Employee ID: ");
		int id = scanner.nextInt();
		
		try
		{
			//attempt to get employee assunming id passd is valid
			Employee employee = employeeService.getEmployee(id);
			//since employee obj is retrieved, updated it and send to database
			
			
			System.out.println("Name:"+ employee.getName());
			System.out.println("Do you Want to Update Name(y/n?");
			char reply = scanner.next().toLowerCase().charAt(0);
			if(reply == 'y') //updating employee name
			{
				System.out.println("Enter new name:");
				String name = scanner.next();
				employee.setName(name);
			}
			
			
			
			
			System.out.println("Department"+ employee.getDepartment());
			System.out.println("Do you Want to Update Department(y/n?");
			 reply = scanner.next().toLowerCase().charAt(0);
			if(reply == 'y') //updating employee name
			{
				System.out.println("Enter new Department:");
				String department = scanner.next();
				employee.setDepartment(department);
			}
			
			
			System.out.println("Designation"+ employee.getDesignation());
			System.out.println("Do you Want to Update Designation(y/n?");
			 reply = scanner.next().toLowerCase().charAt(0);
			if(reply == 'y') //updating employee name
			{
				System.out.println("Enter new Designation:");
				String designation = scanner.next();
				employee.setDesignation(designation);
			}
			
			
			System.out.println("Department"+ employee.getSalary());
			System.out.println("Do you Want to Update Salary(y/n?");
			 reply = scanner.next().toLowerCase().charAt(0);
			if(reply == 'y') //updating employee name
			{
				System.out.println("Enter new Department:");
				float salary = scanner.nextFloat();
				employee.setSalary(salary);
			}
			employeeService.updateEmployee(employee);
		}
		
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	private void removeEmployee() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Remove details");
		System.out.println("\n Employee Id");
		int id = scanner.nextInt();
		try{
			Employee employee = employeeService.removeEmployee(id);
			System.out.println("Employees details REMOVED");
			System.out.println("ID:"  + employee.getId());
			System.out.println("Name:" + employee.getName());
			System.out.println("Department"  + employee.getDepartment());
			System.out.println("Designation"+ employee.getDesignation());
			System.out.println("Salary" + employee.getSalary());
			System.out.println("\n\n");
		}

		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	private void viewEmployee() 
	{
		try
		{
			List<Employee> employees = employeeService.getEmployees();
			
			Iterator<Employee> it = employees.iterator();
			System.out.println("ID \tName \tDepartment \tDesignation \tSalary");
			while(it.hasNext())
			{
				Employee employee = it.next();
				System.out.println(employee.getId()+ "\t"
						+employee.getName()+ "\t"
						+employee.getDepartment()+ "\t"
						+employee.getDesignation()+ "\t"
						+employee.getSalary());
			}
			
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
	}
}
