package com.capgemini.core.ems;

import java.util.List;

import com.capgemini.core.ems.bean.Employee;
import com.capgemini.core.ems.service.EmployeeServiceImpl;

public class TestEmployeeService {
	public static void main(String[] args)
	{
		EmployeeServiceImpl employeeService = new EmployeeServiceImpl();
		
		//Testing addEmployeeMethod
		/*Employee employee = new Employee();
		employee.setName("John");
		employee.setDepartment("IT");
		employee.setDesignation("JavaDev");
		employee.setSalary(12000);
		employeeService.addEmployee(employee);*/
		
		//test getEmployee method
		/*Employee emp = employeeService.getEmployee(1001);
		System.out.println(emp);*/
		// test employee update method
		/*Employee employee = new Employee();
		employee.setId(1001);
		employee.setName("Johnyy");
		employee.setDepartment("IT");
		employee.setDesignation("JavaDev");
		employee.setSalary(307770);
		employeeService.updateEmployee(employee);*/
		//end of test 
		/*Employee employee = new Employee();
		
		employee.setName("Eric");
		employee.setDepartment("ITI");
		employee.setDesignation("COMPUTERS");
		employee.setSalary(3077);
		employeeService.addEmployee(employee);*/
		
		Employee emp = employeeService.removeEmployee(1004);
		System.out.println("Employee removed");
		System.out.println(emp);
		System.out.println();
		
		
		//Test getEmployees method
		List<Employee> emps = employeeService.getEmployees();
		for(Employee employee : emps)
		{
			System.out.println(employee);
		}
		//End of testemployees method
	}

}
