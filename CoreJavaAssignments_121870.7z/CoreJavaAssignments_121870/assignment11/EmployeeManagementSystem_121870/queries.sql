 
drop table employee;

create table Employee( id number, name varchar2(30), department varchar2(30),designation varchar2(30),salary number(10,2),primary key(id));

create sequence empIdSeq start with 1000;
select * from Employee;
select * from Employee;