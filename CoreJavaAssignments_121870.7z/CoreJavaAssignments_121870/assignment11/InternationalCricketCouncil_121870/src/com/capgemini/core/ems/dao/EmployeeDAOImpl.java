package com.capgemini.core.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.core.ems.bean.Employee;
import com.capgemini.core.ems.util.dbutil;

import core.caogemini.core.ems.exception.EmployeeException;

public class EmployeeDAOImpl implements IEmployeeDAO {

	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		// TODO Auto-generated method stub
		int generatedId = -1;
		try(Connection con = dbutil.getConnection())
		{
			
			 Statement stm = con.createStatement();
			
			ResultSet res = stm.executeQuery(" select empIdSeq.nextVal from dual");
			if(res.next() == false)
				throw new EmployeeException("Something went wrong");
			
				int id = res.getInt(1);
				String name = employee.getName();
				float salary = employee.getSalary();
				String dept = employee.getDepartment();
				String desg = employee.getDesignation();
				PreparedStatement pstm = con.prepareStatement("insert into Employee values(?,?,?,?,?)");
				pstm.setInt(1, id);
				pstm.setString(2, name);
				pstm.setString(3, dept);
				pstm.setString(4, desg);
				pstm.setFloat(5, salary);
				pstm.execute();
				generatedId = id;
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new EmployeeException(e.getMessage());
		}
		return generatedId;

	}

	@Override
	public Employee getEmployee(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		Employee employee = null;
		try(Connection con = dbutil.getConnection())
		{
			PreparedStatement pstm = con.prepareStatement("select * from Employee where id=?");
			pstm.setInt(1, id);
			ResultSet res = pstm.executeQuery();
			if(res.next() == false)
				throw new EmployeeException("No such EmployeeId found"+ id);
			employee = new Employee();
			employee.setId(res.getInt("id"));
			employee.setName(res.getString("name"));
			employee.setDepartment(res.getString("department"));
			employee.setDesignation(res.getString("designation"));
			employee.setSalary(res.getFloat("salary"));
				
			
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		return employee;
	}

	@Override
	public void updateEmployee(Employee employee) throws EmployeeException {
		// TODO Auto-generated method stub
		
		try(Connection con = dbutil.getConnection())
		{
			int id = employee.getId();
			String name = employee.getName();
			String dept = employee.getDepartment();
			String desg = employee.getDesignation();
			Float salary = employee.getSalary();
			PreparedStatement pstm = con.prepareStatement("update Employee set name=?, department=?, designation=?, salary=? where id=?");
			pstm.setString(1, name);
			pstm.setString(2, dept);
			pstm.setString(3, desg);
			pstm.setFloat(4, salary);
			pstm.setInt(5, id);
			pstm.execute();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
			
		

	}

	@Override
	public Employee removeEmployee(int id) throws EmployeeException {
		Employee employee = null;
		// TODO Auto-generated method stub
		try(Connection con = dbutil.getConnection())
		{
			employee = getEmployee(id);
			if(employee == null)
			{
				throw new EmployeeException("Employee not exist with id" + id);
			}
			
			PreparedStatement pstm = con.prepareStatement("delete from Employee where id=?");
			pstm.setInt(1, id);
			pstm.execute();
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		
		
		return employee;
	}

	@Override
	public List<Employee> getEmployees() throws EmployeeException {
		List<Employee> employees = new ArrayList<Employee>();
		// TODO Auto-generated method stub
		
		try(Connection con = dbutil.getConnection())
		{
			Statement stm = con.createStatement();
			ResultSet res = stm.executeQuery("select * from Employee");
			while(res.next())
			{
				Employee employee = new Employee();
				employee.setId(res.getInt("id"));
				employee.setName(res.getString("name"));
				employee.setDepartment(res.getString("department"));
				employee.setDesignation(res.getString("designation"));
				employee.setSalary(res.getFloat("salary"));
				employees.add(employee);
			}
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		return employees;
	}

}
