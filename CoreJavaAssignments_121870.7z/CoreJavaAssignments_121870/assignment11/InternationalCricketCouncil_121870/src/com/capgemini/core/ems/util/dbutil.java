package com.capgemini.core.ems.util;

import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.SQLException;

import oracle.jdbc.pool.OracleDataSource;

public class dbutil

{

public static Connection getConnection() throws SQLException

{

OracleDataSource ods = new OracleDataSource();

ods.setUser("Labg103trg15");

ods.setPassword("labg103oracle");

ods.setDriverType("thin");

ods.setNetworkProtocol("tcp");

ods.setURL("jdbc:oracle:thin:@10.125.6.62:1521:orcl11g");

return ods.getConnection();

}

}
