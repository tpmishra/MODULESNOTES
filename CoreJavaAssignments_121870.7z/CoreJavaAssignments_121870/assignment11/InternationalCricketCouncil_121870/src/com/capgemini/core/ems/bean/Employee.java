package com.capgemini.core.ems.bean;

import java.sql.Date;

public class Employee {
	private int playerID;
	private String Name;
	private Date DateOfBirth;
	private String Country;
	private String BattingStyle;
	private int Centuries;
	private int NoMatches;
	private int TotalRun;
	public int getPlayerID() {
		return playerID;
	}
	public void setPlayerID(int playerID) {
		this.playerID = playerID;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Date getDateOfBirth() {
		return DateOfBirth;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + playerID;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (playerID != other.playerID)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Employee [playerID=" + playerID + ", Name=" + Name
				+ ", DateOfBirth=" + DateOfBirth + ", Country=" + Country
				+ ", BattingStyle=" + BattingStyle + ", Centuries=" + Centuries
				+ ", NoMatches=" + NoMatches + ", TotalRun=" + TotalRun + "]";
	}
	public Employee() {
		super();
	}
	public Employee(int playerID, String name, Date dateOfBirth,
			String country, String battingStyle, int centuries, int noMatches,
			int totalRun) {
		super();
		this.playerID = playerID;
		Name = name;
		DateOfBirth = dateOfBirth;
		Country = country;
		BattingStyle = battingStyle;
		Centuries = centuries;
		NoMatches = noMatches;
		TotalRun = totalRun;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		DateOfBirth = dateOfBirth;
	}
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}
	public String getBattingStyle() {
		return BattingStyle;
	}
	public void setBattingStyle(String battingStyle) {
		BattingStyle = battingStyle;
	}
	public int getCenturies() {
		return Centuries;
	}
	public void setCenturies(int centuries) {
		Centuries = centuries;
	}
	public int getNoMatches() {
		return NoMatches;
	}
	public void setNoMatches(int noMatches) {
		NoMatches = noMatches;
	}
	public int getTotalRun() {
		return TotalRun;
	}
	public void setTotalRun(int totalRun) {
		TotalRun = totalRun;
	}
	
	

	
}