package lab9_2;

import static org.junit.Assert.*;

import org.junit.Test;

public class DateTest {
Date date=null;

	

	@Test
	public void testGetDay() {
	date = new Date(9,7,1991);
	assertEquals(9,date.getDay());
	}


	@Test
	public void testGetMonth() {
		date = new Date(9,7,1991);
		assertEquals(7,date.getMonth());
	}

	
	@Test
	public void testGetYear() {
		date = new Date(9,7,1991);
		assertEquals(1991,date.getYear());
	}

}
