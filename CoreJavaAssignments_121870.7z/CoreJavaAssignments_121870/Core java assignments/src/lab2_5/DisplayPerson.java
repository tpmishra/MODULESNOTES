package lab2_5;


public class DisplayPerson
{
	public static void main(String[] args) {

		// TODO Auto-generated method stub

		Person p;

		p=new Person();

		

		p.setFirstName("Tej");

		p.setLastName("Mishra");

	

		p.display();

		GenderAcceptance gender;

		gender=GenderAcceptance.F;

		p.setGender('M');

		p.display();

		}

	}


