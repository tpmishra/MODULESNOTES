package lab2_3;


public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Person p; 
		p = new Person("TEJ","mISHRA",'M');
		
		System.out.println("Person Details");
		System.out.println("--------------");
		
		p.display();
		
		System.out.println("Person Details");
		System.out.println("--------------");
		
		Person p1 = new Person();
		p1.setFirstName("TEJ");
		p1.setLastName("mISHRA");
		p1.setGender('M');
		
		p1.display();
	}

}
