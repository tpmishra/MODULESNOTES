package lab5_3;


public abstract class Account {



	public abstract Person getAccHolder();

	public abstract void setAccHolder(Person accHolder);

	public  abstract double getBalance();

	public abstract void deposit(double amount);

	public abstract void withdraw(double amount);

	
}
