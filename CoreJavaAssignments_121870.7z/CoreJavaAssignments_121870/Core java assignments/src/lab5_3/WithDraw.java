package lab5_3;

public class WithDraw extends Account{

	
	public static int COUNT;
	private long accNum;
	private static double balance;

	private Person accHolder;
	public WithDraw() {
		super();
	}

	public WithDraw(double balance) {
		super();
		COUNT++;
		accNum = COUNT;
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}

	public  double getBalance() {
		return balance;
	}

	public void deposit(double amount) {
		balance += amount;

	}

	public void withdraw(double amount) {
		balance -= amount;
		
	}

	public String toString() {
		return "Account [accNum=" + accNum + ", Initial balance=" + balance
				+ " accHolder=" + accHolder + "]";
	}


}
