package lab4;



public class CurrentAccount extends Account {

	private double OverdraftLimit;

	public double getOverdraftLimit() {
		return OverdraftLimit;
	}

	public void setOverdraftLimit(double overdraftLimit) {
		OverdraftLimit = overdraftLimit;
	}

	public CurrentAccount(double overdraftLimit) {
		super();
		OverdraftLimit = overdraftLimit;
	}

	public CurrentAccount(long accountNo, double balance, Person person,double OverdrawLimit) {
		super(accountNo, balance, person);
		// TODO Auto-generated constructor stub
		
		this.OverdraftLimit = OverdraftLimit;
	}
	public void withdraw(double amount){
		
		if(getBalance()+OverdraftLimit>amount)
		{
			
			setBalance(getBalance()-amount);
			System.out.println("Amount Drawn Successfully from saving account");
		}
		else
		{
			System.out.println("OverdraftLimit Exceeded");
		}
	}
	
}
