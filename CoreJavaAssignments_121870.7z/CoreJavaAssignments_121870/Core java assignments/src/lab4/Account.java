package lab4;



public class Account {

		private long AccountNo;
		private double balance;
		
		private Person person;  //Has a Relationship

		public long getAccountNo() {
			return AccountNo;
		}

		public void setAccountNo(long accountNo) {
			AccountNo = accountNo;
		}

		public double getBalance() {
			return balance;
		}

		public void setBalance(double balance) {
			this.balance = balance;
		}

		public Person getPerson() {
			return person;
		}

		public void setPerson(Person person) {
			this.person = person;
		}
		
		public void deposit(double amount)
		{
			balance += amount;
			System.out.println("Amount deposited successfully ");
		}
		
		public void withdraw(double amount)
		{
			if(balance-amount>500)
			{
				balance -= amount;
				System.out.println("Amount Withdrawn Successfully");
			}
			
			else
			{
				System.out.println("Insufficeient balance");
				
			}
		
			
		}
		public String toString()
		{
			return person.getName()+" "+ AccountNo +" "+balance;
			
		}
		
		public Account(){
			
		}

		public Account(long accountNo, double balance, Person person) {
			super();
			AccountNo = accountNo;
			this.balance = balance;
			this.person = person;
		}
		
}
