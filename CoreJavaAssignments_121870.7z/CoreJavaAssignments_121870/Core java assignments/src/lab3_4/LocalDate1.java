package lab3_4;

import java.time.LocalDate;

import java.time.format.DateTimeFormatter;

import java.util.Scanner;

public class LocalDate1 {

public static void main(String args[])

{

DateTimeFormatter formatter = DateTimeFormatter.ofPattern("DD-MM-YYYY");

Scanner scanner = new Scanner(System.in);

System.out.print("Enter date in DD-MM-YY format:");

String input = scanner.nextLine();



LocalDate start = LocalDate.parse(input,formatter);

System.out.println("Entered Date:"+ input);

System.out.println("Date:"+ start.getDayOfMonth());

System.out.println("Month:"+start.getMonth());

System.out.println("Year:"+ start.getYear());

}

}

