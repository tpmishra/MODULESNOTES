package lab8_1;
import java.io.*;

public class Reverse {

	public static void main(String[] args) {

		BufferedReader bufferedReader  = null;

		BufferedWriter bufferedWriter = null;

		try

		{

		//Reading From File

		bufferedReader = new BufferedReader(new FileReader("D:/lab8/lab8.txt"));

		bufferedWriter = new BufferedWriter(new FileWriter("D:/lab8/lab8_1.txt"));

		String lineRead = bufferedReader.readLine();

		String str="";

		String reverse="";

		while( lineRead != null )

		{

		System.out.println(lineRead);

		char chy[] = lineRead.toCharArray();

		reverse="";

		for(int i=chy.length-1;i>=0;i--)

		{

		char ch=chy[i];

		reverse+=ch;

		}

		str += reverse+" \n ";

		System.out.print(reverse);

		System.out.println();

		lineRead = bufferedReader.readLine();

		}

		bufferedWriter.write(str);

		//Reverse Content

		/* for(int i=chy.length;i>=0;i--)

		{

		char ch= chy[i];

		System.out.print(i);

		}*/

		}

		catch (FileNotFoundException e) {

		// TODO Auto-generated catch block

		e.printStackTrace();

		}

		catch (IOException e) {

		// TODO: handle exception

		e.printStackTrace();

		}

		catch (Exception e) {

		// TODO: handle exception

		e.printStackTrace();

		}

		finally{

		if( bufferedReader != null )

		{

		try

		{

		bufferedReader.close();

		}

		catch ( IOException e ) {

		// TODO Auto-generated catch block

		e.printStackTrace();

		}

		}

		if( bufferedWriter != null )

		{

		try

		{

		bufferedWriter.close();

		}

		catch ( IOException e ) {

		// TODO Auto-generated catch block

		e.printStackTrace();

		}

		}

		}

		}

		}

