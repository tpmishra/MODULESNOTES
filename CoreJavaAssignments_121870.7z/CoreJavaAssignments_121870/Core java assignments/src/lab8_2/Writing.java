package lab8_2;

import java.io.*;
public class Writing 
{

		public static void main(String[] args) {

		BufferedWriter bufferedWriter=null;

		try {

		bufferedWriter=new BufferedWriter(

		new FileWriter("D:/Suraj/Module 2/NumbersLab8.2.txt"));

		for(int i=0;i<=10;i++)

		{

		bufferedWriter.write(i+",");;

		}

		} catch (FileNotFoundException e) {

		// TODO Auto-generated catch block

		e.printStackTrace();

		} catch (IOException e) {

		// TODO Auto-generated catch block

		e.printStackTrace();

		}

		catch(Exception e)

		{

		e.printStackTrace();

		}

		finally{

		if(bufferedWriter!=null)

		{

		try {

		bufferedWriter.close();

		} catch (IOException e) {

		// TODO Auto-generated catch block

		e.printStackTrace();

		}

		}

		}

		}

		}

