package com.cg.bean;

import java.util.Date;

public class ShowDetails {

	private String ShowId;
	private String ShowName;
	private String Location;
	private Date ShowDate;
	private int AvSeats;
	private int PriceTicket;
	@Override
	public String toString() {
		return "ShowDetails [ShowId=" + ShowId + ", ShowName=" + ShowName
				+ ", Location=" + Location + ", ShowDate=" + ShowDate
				+ ", AvSeats=" + AvSeats + ", PriceTicket=" + PriceTicket + "]";
	}
	public ShowDetails() {
		super();
	}
	public ShowDetails(String showId, String showName, String location,
			Date showDate, int avSeats, int priceTicket) {
		super();
		ShowId = showId;
		ShowName = showName;
		Location = location;
		ShowDate = showDate;
		AvSeats = avSeats;
		PriceTicket = priceTicket;
	}
	public String getShowId() {
		return ShowId;
	}
	public void setShowId(String showId) {
		ShowId = showId;
	}
	public String getShowName() {
		return ShowName;
	}
	public void setShowName(String showName) {
		ShowName = showName;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public Date getShowDate() {
		return ShowDate;
	}
	public void setShowDate(Date showDate) {
		ShowDate = showDate;
	}
	public int getAvSeats() {
		return AvSeats;
	}
	public void setAvSeats(int avSeats) {
		AvSeats = avSeats;
	}
	public int getPriceTicket() {
		return PriceTicket;
	}
	public void setPriceTicket(int priceTicket) {
		PriceTicket = priceTicket;
	}
}
