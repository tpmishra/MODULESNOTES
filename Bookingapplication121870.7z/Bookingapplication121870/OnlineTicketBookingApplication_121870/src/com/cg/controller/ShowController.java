package com.cg.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;









import com.cg.bean.ShowDetails;

import com.cg.exception.Bookexception;
import com.cg.service.BookServiceImpl;
import com.cg.service.IBookService;

/**
 * Servlet implementation class ShowController
 */
@WebServlet(urlPatterns={"/Home","/book","/success"})
public class ShowController extends HttpServlet {
	IBookService bookService;
	  public ShowController() {
	      bookService = new BookServiceImpl();
	    }

	
	private static final long serialVersionUID = 1L;
       
    
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}


	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = request.getServletPath();
		String url = "";
		HttpSession sess = null;
		
		IBookService mser =new BookServiceImpl();
		System.out.println(path);
		try{
			switch(path){
			case "/Home":
				List<ShowDetails> mlist = mser.getShowDetails();
				request.setAttribute("mlist", mlist);
				System.out.println(mlist);
				url = "ShowDetails.jsp";
				break;
			case "/book":
				 //mid = Integer.parseInt(request.getParameter("mid"));
				System.out.println("Getting Show Details");

				String mid = request.getParameter("mid") ;

				System.out.println(mid);

				ShowDetails show = mser.getShowDetails(mid);
				

				System.out.println(show);
				sess = request.getSession(true);
				sess.setAttribute("show", "show");
				url="bookNow.jsp";
			

				break;

				

				
			case "/success":

				
				String Id=(String) sess.getAttribute("showid");

				System.out.println(Id);

				int noOfSeats=Integer.parseInt(request.getParameter("txtname5"));

				System.out.println(noOfSeats);

				int status=bookService.updateShowDetails(Id,noOfSeats);

				System.out.println(status);

				if(status==1)

				{

				String showName=request.getParameter("txtname");
				String price=request.getParameter("txtname1");
				String customerName=request.getParameter("txtname2");

				String mobileNo=request.getParameter("txtname3");

				String seats=request.getParameter("txtname4");
				int price1 = Integer.parseInt(price);
				int seats1 = Integer.parseInt(seats);

				

				request.setAttribute("showName",showName);

				request.setAttribute("customerName",customerName);

				request.setAttribute("mobileNo",mobileNo);

				request.setAttribute("seats",seats);

				request.setAttribute("price",price);
				int updatedSeats = seats1-noOfSeats ;
				//String updatedSeats1 = request.getParameter(updatedSeats);
				double totalPrice = price1*noOfSeats ;

				request.setAttribute("totalPrice", totalPrice);

				
				

				
					
				
				
	}
		}
		}
			catch (Bookexception e) {
				request.setAttribute("error", e.getMessage());
				url = "Error.jsp";
				
			}catch(Exception e)
			{
				request.setAttribute("error", e.getMessage());
				url = "Error.jsp";
			}
			RequestDispatcher disp = request.getRequestDispatcher(url);
			disp.forward(request, response);
		}
}



	
