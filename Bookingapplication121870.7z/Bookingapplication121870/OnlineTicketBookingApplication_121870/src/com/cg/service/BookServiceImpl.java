package com.cg.service;

import java.util.List;

import com.cg.bean.ShowDetails;
import com.cg.dao.BookDaoImpl;
import com.cg.dao.IBookDao;
import com.cg.exception.Bookexception;

public class BookServiceImpl implements IBookService {
	IBookDao bookdao ;
	public BookServiceImpl() 
	{
		bookdao = new BookDaoImpl() ;
	}

	@Override
	public List<ShowDetails> getShowDetails() throws Bookexception {
		// TODO Auto-generated method stub
	
		return bookdao.getShowDetails();
	}

	@Override
	public ShowDetails getShowDetails(String ShowId) throws Bookexception {
		// TODO Auto-generated method stub
		return bookdao.getShowDetails(ShowId);
		
	}
	public int updateShowDetails(String showId,int noOfSeats) throws Bookexception{
		 return bookdao.updateShowDetails(showId, noOfSeats);
	}

}
