package com.cg.service;

import java.util.List;

import com.cg.bean.ShowDetails;
import com.cg.exception.Bookexception;

public interface IBookService {
	
	public List<ShowDetails> getShowDetails() throws Bookexception;
	public ShowDetails getShowDetails(String ShowId) throws Bookexception;
	public int updateShowDetails(String showId,int noOfSeats) throws Bookexception;

}
