package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;





import com.cg.bean.ShowDetails;
import com.cg.exception.Bookexception;

import com.cg.util.dbutil;


public class BookDaoImpl implements IBookDao {
	Connection con;
	Statement st;
	PreparedStatement pst;
	ResultSet rs;

	@Override
	public List<ShowDetails> getShowDetails() throws Bookexception {
		String sql = "select * from ShowDetails";
		List<ShowDetails> mlist = new ArrayList<>();
		
		try(Connection conn = dbutil.getConnection())
		{
			
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while(rs.next())
			{
				ShowDetails m = new ShowDetails();
				m.setShowId(rs.getString("showId"));
				m.setShowName(rs.getString("ShowName"));
				m.setLocation(rs.getString("Location"));
				m.setShowDate(rs.getDate("ShowDate"));
				m.setAvSeats(rs.getInt("AvSeats"));
				m.setPriceTicket(rs.getInt("PriceTicket"));
				
				mlist.add(m);
			}
		} catch (SQLException e) {
			throw new Bookexception("Problem in fetching data"+e.getMessage());
		}
		System.out.println("dao mlist"+mlist);
		return mlist;
	}
	@Override
	public ShowDetails getShowDetails(String ShowId) throws Bookexception {
		ShowDetails details = null;
		try(Connection con = dbutil.getConnection())
		{
			PreparedStatement pstm = con.prepareStatement("select * from ShowDetails where ShowId=?");
			
			pstm.setString(1, ShowId);
			ResultSet res = pstm.executeQuery();
			if(res.next() == false)
				throw new Bookexception("No such details found"+ ShowId);
			details = new ShowDetails();
			details.setShowId(res.getString("ShowId"));
			details.setShowName(res.getString("ShowName"));
			details.setLocation(res.getString("Location"));
			details.setShowDate(res.getDate("ShowDate"));
			details.setAvSeats(res.getInt("AvSeats"));
			details.setPriceTicket(res.getInt("PriceTicket"));
			
				
			
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new Bookexception(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new Bookexception(e.getMessage());
		}
		return details;
	}
	public int updateShowDetails(String showId,int noOfSeats) throws Bookexception{

		int flag=0;

		try {

		con=dbutil.getConnection();

		String selectQuery="SELECT AvSeats FROM SHOWDETAILS WHERE SHOWID=?";

		pst=con.prepareStatement(selectQuery);

		pst.setString(1,showId);

		rs=pst.executeQuery();

		if(rs.next()==false)

			throw new Bookexception("No such details found");

		int availableSeats=rs.getInt(1);

		if(availableSeats>=noOfSeats)

		{

		PreparedStatement pst=con.prepareStatement("update ShowDetails set AvSeats=AvSeats-? where ShowId=?");

		pst.setInt(1,noOfSeats);

		pst.setString(2,showId);

		pst.execute();

		flag=1;

		}

		else

		{

		flag=0;

		}

		} catch (SQLException e) {

		// TODO Auto-generated catch block

		e.printStackTrace();

		}

		return flag;

		}

		}
		
	


