package com.cg.exception;

public class Bookexception extends Exception{
	public Bookexception()
	{
		
	}
	public Bookexception(String message)
	{
		super(message);
	}
}

