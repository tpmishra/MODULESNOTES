package com.cg.ebc.controller;

import java.io.IOException;

import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ebc.bean.BillDetails;
import com.cg.ebc.bean.Consumers;
import com.cg.ebc.service.EBillServiceImpl;
import com.cg.ebc.service.IEBillService;



@WebServlet(urlPatterns= {"/ShowBillDetails","/List","/SearchConsumer","/InsertForm","CalculateBill"})
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ServletConfig  conf;
	IEBillService service=new EBillServiceImpl();
    public EBillController() {
        super();
      
    }


	public void init(ServletConfig config) throws ServletException {
	
	}

	
	public void destroy() {
	
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("In doPost() Controller");
		
		IEBillService service=new EBillServiceImpl();
		String path=request.getServletPath();
		System.out.println(path);
		String url= null;
		switch(path)
		{
		
			case "/List":
				
				List<Consumers> clist=service.getConsumers();
				System.out.println(clist);
				request.setAttribute("clist", clist);
				url="ConsumersList.jsp";
				
				break;
			case "/ShowBillDetails":
				String action=request.getParameter("cid");
				int consumerid=Integer.parseInt(action);
				System.out.println(consumerid);
				List billList=service.getBillDetails(consumerid);
				
				Consumers c=service.getConsumer(consumerid);
				System.out.println(c);
				request.setAttribute("consumer", c);
				System.out.println(billList);
				request.setAttribute("billList", billList);
				url="ShowBillDetails.jsp";
				break;
				
			case "/SearchConsumer":
				int cid=Integer.parseInt(request.getParameter("txtConsumerId"));
				Consumers consumer=service.getConsumer(cid);
				request.setAttribute("consumer", consumer);
				url="ShowConsumer.jsp";
				break;
				
			case "/InsertForm":
				int conid=Integer.parseInt(request.getParameter("cid"));
				request.setAttribute("conId",conid );
				System.out.println(conid);
				url="InsertForm.jsp";
				break;
			case "/CalculateBill":
				
				System.out.println("In validateConsumer");
				String consid=request.getParameter("txtCId");
				String currReading=request.getParameter("txtCMR");
				String lastReading=request.getParameter("txtLMR");
				
				int id=Integer.parseInt(consid);
				double cr=Double.parseDouble(currReading);
				double lr=Double.parseDouble(lastReading);
				BillDetails billDetails=null;
				BillDetails bill=null;
				if(cr>lr)
				{
					double units=cr-lr;
					int fixedCharge=100;
					double billamount=units*0.15+fixedCharge;
					billDetails=new BillDetails();
					
					billDetails.setConsumer_num(id);
					billDetails.setCur_reading(cr);
					billDetails.setUnitsConsumed(units);
					billDetails.setNetAmount(billamount);
					
					bill=new BillDetails();
					bill=service.addBillDetails(billDetails);
					request.setAttribute("bill", bill);
					
					Consumers consumer1=service.getConsumer(id);
					request.setAttribute("consumer", consumer1);
					
					url="Bill_Info.jsp";
				}
				else
				{
					url="Error.jsp";
				}
				 
			}
		
		RequestDispatcher rd = request.getRequestDispatcher(url) ;
		rd.forward(request, response);
			
			
		}
	}


