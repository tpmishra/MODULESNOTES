package com.cg.ebc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;




import java.util.List;

import com.cg.ebc.bean.BillDetails;
import com.cg.ebc.bean.Consumers;
import com.cg.ebc.util.DBUtil;


public class EBillDaoImpl implements IEBillDao{

	Connection con;
	Statement st;
	PreparedStatement pst;
	ResultSet rs;
	@Override
	public boolean isConsumerExists(int consumerNo) {
		boolean flag=false;
		try{
			con=DBUtil.getConnection();
			System.out.println("In Dao");
		System.out.println("In user dao con is "+con);
		String selectQuery="SELECT COUNT(*) FROM CONSUMERS WHERE CONSUMER_NUM=?";
		
		pst=con.prepareStatement(selectQuery);
		pst.setInt(1,consumerNo);
		rs=pst.executeQuery();
		rs.next();
		int count=rs.getInt(1);
		if(count==1)
		{
			flag= true;
		}
		else
		{
			flag=false;
		}
			
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		finally{
			try{
			rs.close();
			pst.close();
			con.close();
			}
		catch (SQLException e) {
		
			e.printStackTrace();
		}
		}
		return flag;
	}

	@Override
	public Consumers getConsumer(int consumerNo) {
	
		Consumers consumer=null;
		try {
			con=DBUtil.getConnection();
	
		System.out.println("In consumer dao con is "+con);
		String selectQuery="SELECT * FROM CONSUMERS WHERE CONSUMER_NUM=?";
		
		pst=con.prepareStatement(selectQuery);
		pst.setInt(1,consumerNo);
		rs=pst.executeQuery();
		rs.next();
		consumer=new Consumers();
		consumer.setConsumer_num(rs.getInt(1));
		consumer.setConsumer_name(rs.getString(2));
		consumer.setConsumer_addr(rs.getString(3));
	}
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			try{
			rs.close();
			pst.close();
			con.close();
			}
		catch (SQLException e) {
		
			e.printStackTrace();
		}
		}
		return consumer;
	}

	@Override
	public BillDetails addBillDetails(BillDetails bill) {
	
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		/*Date date = new Date();
		java.sql.Date dt= (java.sql.Date) date;*/
		long millis=System.currentTimeMillis();  
        java.sql.Date dt=new java.sql.Date(millis); 
		bill.setBillDate(dt);
	
		
		try {
			con=DBUtil.getConnection();
		
			Statement stm=con.createStatement();
			ResultSet rs=stm.executeQuery("select seq_bill_num.nextVal from dual");
			if(rs.next()==false)
				System.out.println("Something went wrong");
			int id=rs.getInt(1);
			bill.setBil_num(id);
			String insertQuery="INSERT INTO BILLDETAILS VALUES(?,?,?,?,?,?)";
			pst=con.prepareStatement(insertQuery);
			pst.setInt(1, id);
			pst.setInt(2, bill.getConsumer_num());
			pst.setDouble(3,bill.getCur_reading());
			pst.setDouble(4,bill.getUnitsConsumed());
			pst.setDouble(5, bill.getNetAmount());
			pst.setDate(6,bill.getBillDate());
			pst.execute();
			
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			
			
				try {
					pst.close();
					con.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			
		}
		return bill;
	}

	@Override
	public List<Consumers> getConsumers() {
		// TODO Auto-generated method stub
		List<Consumers> clist=new ArrayList<Consumers>();
		Consumers consumer=null;
		try {
			con=DBUtil.getConnection();
			String sql="SELECT * FROM CONSUMERS";
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(sql);
		
			while(rs.next())
			{
				consumer=new Consumers();
				consumer.setConsumer_num(rs.getInt(1));
				consumer.setConsumer_name(rs.getString(2));
				consumer.setConsumer_addr(rs.getString(3));
				clist.add(consumer);
			}
			
			
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return clist;
	}

	@Override
	public List<BillDetails> getBillDetails(int consumerno) {
		
		List<BillDetails> billList=new ArrayList<BillDetails>();
		BillDetails billDetails=null;
		String sql="SELECT * FROM BILLDETAILS WHERE CONSUMER_NUM=?";
		try {
			con=DBUtil.getConnection();
			pst=con.prepareStatement(sql);
			pst.setInt(1, consumerno);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
			billDetails=new BillDetails();
			billDetails.setBil_num(rs.getInt(1));
			billDetails.setConsumer_num(rs.getInt(2));
			billDetails.setCur_reading(rs.getDouble(3));
			billDetails.setUnitsConsumed(rs.getDouble(4));
			billDetails.setNetAmount(rs.getDouble(5));
			billDetails.setBillDate(rs.getDate(6));
			billList.add(billDetails);
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return billList;
	}



	
}
