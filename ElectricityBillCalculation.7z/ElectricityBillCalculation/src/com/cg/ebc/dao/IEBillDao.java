package com.cg.ebc.dao;



import java.util.List;

import com.cg.ebc.bean.BillDetails;
import com.cg.ebc.bean.Consumers;

public interface IEBillDao {

	public boolean isConsumerExists(int consumerNo);
	public Consumers getConsumer(int consumerNo);
	public BillDetails addBillDetails(BillDetails billDetails);
	public List<Consumers> getConsumers();
	public List<BillDetails> getBillDetails(int consumerno);
	
}
