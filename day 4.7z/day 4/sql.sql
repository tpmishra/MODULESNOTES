3.1

SQL> create or replace function E_age(ag emp.hiredate%type)

2 return number

3 is a_age number(3,1);

4 begin

5 a_age:= TRUNC(months_between(sysdate,ag))/12;

6 return(a_age);

7 end E_age;

8 /

Function created.

SQL> create or replace procedure proc_8(e in date)

2 as

3 years number(10);

4 begin

5 years:=E_age(e);

6 dbms_output.put_line('The Age is '||years);

7 end;

8 /

Procedure created.

SQL>exec proc_8('06-mar-15');

The Age is 2

PL/SQL procedure successfully completed.

3.2

SQL> create or replace procedure mng

2 as

3 scode staff_master.staff_code%type;

4 sname staff_master.staff_name%type;

5 sdeptno staff_master.dept_code%type;

6 ssmgrname staff_master.staff_name%type;

7 cursor cc1 is select s.staff_code,s.staff_name,s.dept_code,ss.staff_name from staff_master

s,staff_master ss wheres.mgr_code=ss.staff_code;

8 begin

9 open cc1;

10 loop

11 fetch cc1 into scode, sname, sdeptno, ssmgrname;

12 exit when cc1%notfound;

13 dbms_output.put_line(scode||' '||sname||' '||sdeptno||' '||ssmgrname);

14 end loop;

15 close cc1;

16 end;

17 /

Procedure created.

SQL> exec mng;

100006 Allen 30 John

100007 Smith 20 John

100009 Rahul 20 Allen

100008 Raviraj 40 Allen

100003 Mohan 10 Allen

100004 Anil 20 Allen

100001 Arvind 30 Allen

100010 Ram 30 Smith

100002 Shyam 20 Smith

100005 John 10 Smith

PL/SQL procedure successfully completed.

3.3

SQL> create or replace function calc(s staff_master.staff_code%type)

2 return number

3 is

4 da number(10);

5 hra number(10);

6 ta number(10);

7 spc_allwnce number(10);

8 total number(10);

9 s_sal staff_master.staff_sal%type;

10 joining staff_master.hiredate%type;

11 experience number(10);

12 begin

13 select staff_sal, hiredate into s_sal,joining from staff_master where staff_code=s;

14 da:=s_sal*0.15;

15 hra:=s_sal*0.8;

16 ta:=s_sal*0.8;

17 experience:=trunc(months_between(sysdate,joining))/12;

18 if(experience < 1) then

19 spc_allwnce:=0;

20 end if;

21 if(experience >= 1 and experience < 2) then

22 spc_allwnce:=s_sal * 0.1;

23 end if;

24 if(experience >= 2 and experience < 4) then

25 spc_allwnce:=s_sal * 0.2;

26 end if;

27 if(experience > 4) then

28 spc_allwnce:=s_sal * 0.3;

29 end if;

30 total:=da + hra + ta + spc_allwnce;

31 return(total);

32 end calc;

33 /

Function created.

SQL> create or replace procedure prr1(stffcode in number)

2 as

3 cost number(10);

4 begin

5 cost:= calc(stffcode);

6 dbms_output.put_line('Total cost is '||' '||cost);

7 end prr1;

8 /

Procedure created.

SQL> exec prr1(100008);

Total cost is 36900

PL/SQL procedure successfully completed.

SQL> exec prr1(100009);

Total cost is 45100

PL/SQL procedure successfully completed.
Jay Pandey