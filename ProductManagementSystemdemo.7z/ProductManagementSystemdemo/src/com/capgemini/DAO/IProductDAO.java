package com.capgemini.DAO;



import java.util.List;

import com.capgemini.Exception.ProductException;
import com.capgemini.entities.Product;

public interface IProductDAO
{
	public int addProduct(Product product) throws ProductException;
	public void updateProduct(Product product) throws ProductException;
	public Product getProduct(int id) throws ProductException;
	public void removeProduct(int id) throws ProductException;
	public List<Product> getAllProducts() throws ProductException;
	public Product getProduct(String name) throws ProductException;
	//public Product getProductPrice(int price1,int price2) throws ProductException;
	List<Product> getAllProducts(float Price1, float price2)
			throws ProductException;
}
