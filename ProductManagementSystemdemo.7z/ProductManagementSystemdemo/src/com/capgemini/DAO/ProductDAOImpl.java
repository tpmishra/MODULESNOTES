package com.capgemini.DAO;


import java.util.List;



import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.capgemini.Exception.ProductException;
import com.capgemini.dbutil.dbutil;
import com.capgemini.entities.Product;

public class ProductDAOImpl implements  IProductDAO {
	private EntityManager entityManager;
	 public ProductDAOImpl() {
		entityManager = dbutil.getEntityManager();
	}

	@Override
	public int addProduct(Product product) throws ProductException {
		// TODO Auto-generated method stub
		
		int productId = 0;
		
		try{
			entityManager.getTransaction().begin();
			
			entityManager.persist(product);
			
			productId = product.getId();
			
			entityManager.getTransaction().commit();
			
		}
		catch(Exception e)
		{
			entityManager.getTransaction().rollback();
			throw new ProductException(e.getMessage());
		}
		return productId;
	}

	@Override
	public void updateProduct(Product product) throws ProductException {
		try{
			entityManager.getTransaction().begin();
			
			entityManager.merge(product);
			
			entityManager.flush();
			
			entityManager.getTransaction().commit();
			
		}
		catch(Exception e)
		{
			entityManager.getTransaction().rollback();
			throw new ProductException(e.getMessage());
		}

	}

	@Override
	public Product getProduct(int id) throws ProductException {
		Product product = null;
		try{
			entityManager.getTransaction().begin();
			
			product = entityManager.find(Product.class, id);
			entityManager.getTransaction().commit();
			
		}
		catch(Exception e)
		{
			entityManager.getTransaction().rollback();
			throw new ProductException(e.getMessage());
		}
		if(product == null)
				throw new ProductException("No product found with id" +id);
		return product;
	}

	@Override
	public void removeProduct(int id) throws ProductException {
		

		try{
			entityManager.getTransaction().begin();
			
			Product product = entityManager.find(Product.class, id);
			entityManager.remove(product);
			
			entityManager.getTransaction().commit();
			
		}
		catch(Exception e)
		{
			entityManager.getTransaction().rollback();
			throw new ProductException(e.getMessage());
		}
	}

	@Override
	public List<Product> getAllProducts() throws ProductException {
		List<Product> products = null;
		try
		{
			EntityTransaction transaction = entityManager.getTransaction();
			transaction.begin();
			TypedQuery<Product> tQuery = entityManager.createNamedQuery("GetAllProducts",Product.class);
			products = tQuery.getResultList();
			
			
			
			
			transaction.commit();
			
		}
	
		catch(Exception e)
		{
			throw new ProductException(e.getMessage());
		}
		if(products == null || products.isEmpty())
			throw new ProductException("No products to display");
		return products;
	}

	@Override
	public Product getProduct(String name) throws ProductException {
		
	Product product = null;
		try{
		EntityTransaction transaction = entityManager.getTransaction();
		
		transaction.begin();
		
		TypedQuery<Product> pQuery = entityManager.createQuery("select t from Product t where t.name =:name",Product.class);
		pQuery.setParameter("name", name);
		product = pQuery.getSingleResult();
		
		//product = entityManager.find(Product.class, product);
		transaction.commit();
		
	}
	catch(Exception e)
	{
		throw new ProductException(e.getMessage());
	}
	return product;
	}

	@Override
	public List<Product> getAllProducts(float Price1,float price2) throws ProductException  {
		List<Product> products = null;
		try{
EntityTransaction transaction = entityManager.getTransaction();
		
		transaction.begin();
		TypedQuery<Product> pQuery = entityManager.createQuery("select t from Product t" + " where t.price BETWEEN :p1 AND :p2", Product.class);
		pQuery.setParameter("p1",Price1);
		pQuery.setParameter("p2",price2);
		products =  pQuery.getResultList();
		transaction.commit();
		
	}
	catch(Exception e)
	{
		throw new ProductException(e.getMessage());
	}
		if(products == null)
			throw new ProductException("No product found with id" +Price1);
	
	return products;
	
}
}
