package com.capgemini.UI;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.Exception.ProductException;
import com.capgemini.Service.IProductService;
import com.capgemini.Service.ProductServiceImpl;
import com.capgemini.entities.Product;

public class Menu {
	private IProductService productService;
	public Menu()
	{
		productService = new ProductServiceImpl();
	}
	
	
	public void menu()
	{
		Scanner console = new Scanner(System.in);
		System.out.println("1)Add Product");
		System.out.println("2)GET PRODUCT");
		System.out.println("3)UPDATE PRODUCT");
		System.out.println("4)ReMOVE pRODUCT");
		System.out.println("5)View product");
		System.out.println("6)Exit application");
		System.out.println("7)Get Name");
		System.out.println("8)Get Range of price");
		int choice = console.nextInt();
		switch (choice) {
			case 1:
				System.out.println("Enter product name");
				String name = console.next();
				
				System.out.println("Enter Quantity");
				int quantity = console.nextInt();
				
				System.out.println("Enter price");
				float price = console.nextFloat();
				
				Product p1 = new Product(name,quantity,price);
				try{
				
				int productId = productService.addProduct(p1);
				System.out.println("Product inserted successfully with id"+productId);
				}
				catch(ProductException e)
				{
					System.out.println("Could not add because"+e.getMessage());
				}
				catch(Exception e)
				{
					System.out.println(e.getMessage());
				}
				
			
			break;
			case 2:
				System.out.println("Enter the id to retrieve");
				System.out.println("product Id:");
				int productId = console.nextInt();
				try
				{
					Product p2 = productService.getProduct(productId);
					System.out.println("id"+p2.getId());
					System.out.println("name"+p2.getName());
					System.out.println("quantity"+p2.getQuantity());
					System.out.println("price"+p2.getPrice());
				}
				catch(ProductException e)
				{
					System.out.println("Could not fetch because"+e.getMessage());
				}
				catch(Exception e)
				{
					System.out.println(e.getMessage());
				}
				
				break;
				
			case 3:
				System.out.println("Enter Product id to update");
				int id1 = console.nextInt();
				Product p3 = null;
				try
				{
				 p3 = productService.getProduct(id1);
					System.out.println("Old product name:"+p3.getName());
					System.out.println("Update?y/n");
					char reply = console.next().toLowerCase().charAt(0);
					if(reply == 'y')
					{
						System.out.println("Enter new name");
						String newName = console.next();
						p3.setName(newName);
					}
					
					System.out.println("Old product Quantity:"+p3.getQuantity());
					System.out.println("Update?y/n");
					 reply = console.next().toLowerCase().charAt(0);
					if(reply == 'y')
					{
						System.out.println("Enter new Quantity");
						int Quantity = console.nextInt();
						p3.setQuantity(Quantity);
					}
					
					System.out.println("Old product price:"+p3.getPrice());
					System.out.println("Update?y/n");
					 reply = console.next().toLowerCase().charAt(0);
					if(reply == 'y')
					{
						System.out.println("Enter new price");
						float price1 = console.nextFloat();
						p3.setPrice(price1);
					}
					
					
					
					
					
				}
				catch(ProductException e)
				{
					System.out.println("Product not found"+e.getMessage());
				}
				catch(Exception e)
				{
					System.out.println(e.getMessage());
				}
				try
				{
					if(p3!=null)
					productService.updateProduct(p3);
				}
				catch(ProductException e)
				{
					System.out.println("Could not update"+e.getMessage());
				}
				catch(Exception e)
				{
					System.out.println(e.getMessage());
				}
				
				
				
				break;
			case 4:
				System.out.println("Remove Products");
				System.out.println("Enter product id");
				int id2 = console.nextInt();
				try
				{
					 productService.removeProduct(id2);
					
				}
				catch(ProductException e)
				{
					System.out.println("Could not remove product"+e.getMessage());
				}
				catch(Exception e)
				{
					System.out.println(e.getMessage());
				}
				
				
				break;
			case 5:
				try
				{
					List<Product> products = productService.getAllProducts();
					Iterator<Product> it = products.iterator();
					System.out.printf("%s %2s %15s %s","ID","NAME","QUANTITY","PRICE");
					while(it.hasNext())
					{
						Product product = it.next();
						System.out.print(product.getId() + " ");
						System.out.print(product.getName() + " ");
						System.out.print(product.getQuantity() + " ");
						System.out.print(product.getPrice() + " "+"\n");
					}
					
				}
				catch(ProductException e)
				{
					System.out.println("Could not display all product"+e.getMessage());
				}
				catch(Exception e)
				{
					System.out.println(e.getMessage());
				}
				
				
				
				
				
				
			case 6:
			System.out.println("Thank You ! Exiting Application");
			System.exit(0);
		break;
			case 7:
				System.out.println("Enter the name to retrieve");
				System.out.println("product nmae:");
				String name4 = console.next();
				try
				{
					Product p2 = productService.getProduct(name4);
					System.out.println("id"+p2.getId());
					System.out.println("name"+p2.getName());
					System.out.println("quantity"+p2.getQuantity());
					System.out.println("price"+p2.getPrice());
				}
				catch(ProductException e)
				{
					System.out.println("Could not fetch because"+e.getMessage());
				}
				catch(Exception e)
				{
					System.out.println(e.getMessage());
				}
				
				break;
			case 8:
				System.out.println("Enter price1");
				float Price1 = console.nextFloat();
				System.out.println("Enter price2");
				float price2 = console.nextFloat();
				try
				{
					List<Product> products  = productService.getAllProducts(Price1, price2);
					System.out.printf("%s %2s %15s %s","ID","NAME","QUANTITY","PRICE");
					Iterator<Product> it = products.iterator();
				
					while(it.hasNext())
					{
						Product product = it.next();
						System.out.print(product.getId() + " ");
						System.out.print(product.getName() + " ");
						System.out.print(product.getQuantity() + " ");
						System.out.print(product.getPrice() + " "+"\n");
					}
					
				}
			//	catch(ProductException e)
			//	{
			//		System.out.println("Could not display all product"+e.getMessage());
				//}
				catch(Exception e)
				{
					System.out.println(e.getMessage());
				}
				
				
				
				
				
				
				
				
				
				
		default:
			System.out.println("Invalid choice");
			break;
		}
	}
	
	public static void main(String[] args) {
		
		
		
		Menu application = new Menu();
		while(true)
		{
			try{
			
		application.menu();
		}
			catch(Exception e)
			{
				System.out.println("something went wrong"+e.getMessage());
			}
		}
			
		
	}

}
