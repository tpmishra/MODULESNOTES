package com.capgemini.dbutil;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class dbutil
{
	public static EntityManager getEntityManager()
	{
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		//GET MANAGER
		EntityManager entityManager = factory.createEntityManager();
		return entityManager;
	}
}
