package com.capgemini.Test;

import com.capgemini.Service.ProductServiceImpl;
import com.capgemini.entities.Product;

public class Test {
	public static void main(String[] args) {
		
	ProductServiceImpl productService = new ProductServiceImpl();
	
	//tetsing add method
	Product p1 = new Product("Ht",10,23000);
	int id = productService.addProduct(p1);
	System.out.println("product with id"+id);
	
	//testing get product
	
	Product p2 = productService.getProduct(id);
	System.out.println(p2);
	
	//testing update method
	
	Product p3 = new Product(id,"jh",8,12000);
	productService.updateProduct(p3);
	System.out.println(p3);
	
	
	//testting remove method
	
	productService.removeProduct(id);
	//productService.removeProduct(p1);
	System.out.println(productService.getProduct(id));

}
}