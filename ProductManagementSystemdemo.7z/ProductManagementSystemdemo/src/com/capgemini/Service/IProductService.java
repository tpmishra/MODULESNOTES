package com.capgemini.Service;

import java.util.List;

import com.capgemini.Exception.ProductException;
import com.capgemini.entities.Product;

public interface IProductService {
	
	public int addProduct(Product product) throws ProductException;
	public void updateProduct(Product product) throws ProductException;
	public Product getProduct(int id) throws ProductException;
	public void removeProduct(int id) throws ProductException;
	public List<Product> getAllProducts() throws ProductException;
	public Product getProduct(String name) throws ProductException;
	List<Product> getAllProducts(float Price1, float price2)
			throws ProductException;

}
