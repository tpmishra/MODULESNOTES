package com.capgemini.Service;

import java.util.List;

import com.capgemini.DAO.IProductDAO;
import com.capgemini.DAO.ProductDAOImpl;
import com.capgemini.Exception.ProductException;
import com.capgemini.entities.Product;

public class ProductServiceImpl implements IProductService {
	private IProductDAO productDAO;
	public ProductServiceImpl()
	{
		productDAO = new ProductDAOImpl();
	}
	@Override
	public int addProduct(Product product) throws ProductException {
		// TODO Auto-generated method stub
		return productDAO.addProduct(product);
	}

	@Override
	public void updateProduct(Product product) throws ProductException {
		// TODO Auto-generated method stub
		productDAO.updateProduct(product);

	}

	@Override
	public Product getProduct(int id) throws ProductException {
		// TODO Auto-generated method stub
		return productDAO.getProduct(id);
	}

	@Override
	public void removeProduct(int id) throws ProductException {
		// TODO Auto-generated method stub
		productDAO.removeProduct(id);

	}
	@Override
	public List<Product> getAllProducts() throws ProductException {
		// TODO Auto-generated method stub
		return productDAO.getAllProducts();
	}
	@Override
	public Product getProduct(String name) throws ProductException {
		// TODO Auto-generated method stub
		return productDAO.getProduct(name);
	}
	@Override
	public List<Product> getAllProducts(float Price1, float price2)
			throws ProductException {
		// TODO Auto-generated method stub
		return productDAO.getAllProducts(Price1, price2);
	}

}
