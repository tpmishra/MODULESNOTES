package com.cg.ser;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.bean.BillDetails1;
import com.cg.bean.Consumer1;
import com.cg.mpa.exception.MobileException;
import com.cg.service.BillServiceImpl;
import com.cg.service.IBillService;


@WebServlet(urlPatterns={"/home","/bill","/detail","/billed","/generate","/inserted"})

public class BillController extends HttpServlet {
	IBillService billService;
	public BillController()
	{
		billService = new BillServiceImpl();
	}
	private static final long serialVersionUID = 1L;
       

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = request.getServletPath();
		String url = "";
		HttpSession sess;
		IBillService mser =new BillServiceImpl();
		System.out.println(path);
		try{
			switch(path){
			case "/home":
				List<Consumer1> mlist = mser.getConsumers1();
				request.setAttribute("mlist", mlist);
				System.out.println(mlist);
				url = "Home.jsp";
				break;
			
			
			case "/bill":
				int mid = Integer.parseInt(request.getParameter("mid"));
				sess = request.getSession(true);
				sess.setAttribute("mid", mid);
				url = "Insert.jsp";
				break;
			case "/detail":
				
				String conNum = request.getParameter("cname");
				int Consumernumber = Integer.parseInt(conNum);
				Consumer1 consume = billService.getConsumer1(Consumernumber);
				request.setAttribute("consume", consume);
				url = "Success.jsp";
				break;
				
			case "/billed":
				
				
				int cons_num = Integer.parseInt(request.getParameter("conNum"));
				List<BillDetails1> mlist1 = mser.getBillDetails1(cons_num);
				System.out.println(mlist1);
				request.setAttribute("mlist1", mlist1);
				url = "Home1.jsp";
				break;
				
			case "/generate":
				
				url = "Home2.jsp";
				break;
				
			case "/inserted":
				System.out.println("In validateConsumer");
				String consid=request.getParameter("txtConNum");
				String currReading=request.getParameter("txtLMR");
				String lastReading=request.getParameter("txtCMR");
				
				int id=Integer.parseInt(consid);
				int cr=Integer.parseInt(currReading);
				int lr=Integer.parseInt(lastReading);
				BillDetails1 billDetails=null;
				BillDetails1 bill=null;
				if(cr>lr)
				{
					int units=cr-lr;
					int fixedCharge=100;
					double billamount=units*0.15+fixedCharge;
					billDetails=new BillDetails1();
					billDetails.setConsumernum(id);
					billDetails.setCurrentreading(cr);
					billDetails.setUnitConsumed(units);
					billDetails.setNetamount(billamount);
					
					
					bill=new BillDetails1();
					bill=billService.addBillDetails1(billDetails);
					request.setAttribute("bill", bill);
					
					Consumer1 consumer1=billService.getConsumer1(id);
					request.setAttribute("consumer1", consumer1);
					
					url="Bill_Info.jsp";
			
				
				
			
				
				
		}}
			}

		
			catch (MobileException e) {
				request.setAttribute("error", e.getMessage());
				url = "Error.jsp";
				
			}catch(Exception e)
			{
				request.setAttribute("error", e.getMessage());
				url = "Error.jsp";
			}
			RequestDispatcher disp = request.getRequestDispatcher(url);
			disp.forward(request, response);
		}
}

		
	


