package com.cg.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;







import com.cg.bean.BillDetails1;
import com.cg.bean.Consumer1;
import com.cg.dbutil.dbutil;

import com.cg.mpa.exception.MobileException;




public class BillDAOImpl implements IBillDAO 
{
	


Connection con;
Statement st;
PreparedStatement pst;
ResultSet rs;
	
	@Override
	public List<Consumer1> getConsumers1() throws MobileException
	{
		
			String sql = "select * from Consumers1";
			List<Consumer1> mlist = new ArrayList<>();
			
			try(Connection conn = dbutil.getConnection())
			{
				
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery(sql);
				while(rs.next())
				{
					Consumer1 m = new Consumer1();
					m.setConsumernum(rs.getInt("consumer_num"));
					m.setConsumer_name(rs.getString("consumer_name"));
					m.setAddress(rs.getString("address"));
		
					mlist.add(m);
				}
			} catch (SQLException e) {
				throw new MobileException("Problem in fetching data"+e.getMessage());
			}
			System.out.println("dao mlist"+mlist);
			return mlist;
		}

	@Override
	public Consumer1 getConsumer1(int id) throws MobileException {
		Consumer1 consumer = null;
		try(Connection con = dbutil.getConnection())
		{
			PreparedStatement pstm = con.prepareStatement("select * from Consumers1 where consumer_num=?");
			pstm.setInt(1, id);
			ResultSet res = pstm.executeQuery();
			if(res.next() == false)
				throw new MobileException("No such consumer found found"+ id);
			consumer = new Consumer1();
			consumer.setConsumernum(res.getInt("consumer_num"));
			consumer.setConsumer_name(res.getString("consumer_name"));
			consumer.setAddress(res.getString("address"));
			/*employee.setId(res.getInt());
			employee.setName(res.getString("name"));
			employee.setDepartment(res.getString("department"));
			employee.setDesignation(res.getString("designation"));
			employee.setSalary(res.getFloat("salary"));*/
				
			
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new MobileException(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new MobileException(e.getMessage());
		}
		return consumer;
	}
	public List<BillDetails1> getBillDetails1(int cons_num) throws MobileException {
		
		// TODO Auto-generated method stub
		Connection conn = null;
		String sql = "select * from billdetails1 where consumer_num=?";
		List<BillDetails1> mlist1 = new ArrayList<>();
		BillDetails1 m = null;
			try {
				conn = dbutil.getConnection();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		try{
			
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1,cons_num);
			ResultSet rs =pst.executeQuery();
			while(rs.next())
			{
				m=new BillDetails1();
				m.setBillnumber(rs.getInt("BILL_NUM"));
				m.setConsumernum(rs.getInt("CONSUMER_NUM"));
				m.setCurrentreading(rs.getInt("cur_reading"));
				m.setUnitConsumed(rs.getInt("UNITCONSUMED"));
				m.setNetamount(rs.getInt("NETAMOUNT"));
				m.setBill_date(rs.getDate("BILL_DATE"));
				
				
				
			
				mlist1.add(m);
				System.out.println(mlist1);
			}
		} catch (SQLException e) {
			throw new MobileException("Problem in fetching data"+e.getMessage());
		}
		return mlist1;
	}
	public BillDetails1 addBillDetails1(BillDetails1 billdetails) throws MobileException {
		int generatedId = -1;
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		/*Date date = new Date();
		java.sql.Date dt= (java.sql.Date) date;*/
		long millis=System.currentTimeMillis();  
        java.sql.Date dt=new java.sql.Date(millis); 
		
		
        try {
			con=dbutil.getConnection();
		
			Statement stm=con.createStatement();
			ResultSet rs=stm.executeQuery("select seq_bill_num.nextVal from dual");
			if(rs.next()==false)
				System.out.println("Something went wrong");
			int id=rs.getInt(1);
			billdetails.setBillnumber(id);
			String insertQuery="INSERT INTO BILLDETAILS1 VALUES(?,?,?,?,?,?)";
			pst=con.prepareStatement(insertQuery);
			pst.setInt(1, id);
			pst.setInt(2, billdetails.getConsumernum());
			pst.setInt(3, billdetails.getCurrentreading());
			pst.setDouble(4, billdetails.getUnitConsumed());
			pst.setDouble(5, billdetails.getNetamount());
			pst.setDate(6, billdetails.getBill_date());
			
			pst.execute();
			
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			
			
				try {
					pst.close();
					con.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			
		}
		return billdetails;
	}
}
			
	/*public BillDetails1 getBillDetail1(int id) throws MobileException
	{
		BillDetails1 billDetails = null;
		try(Connection con = dbutil.getConnection())
		{
			PreparedStatement pstm = con.prepareStatement("select * from BillDetails1 where consumer_num =?");
			pstm.setInt(1, id);
			ResultSet rs = pstm.executeQuery();
			if(rs.next() == false)
				throw new MobileException("No such consumer found found"+ id);

			billDetails = new BillDetails1();
			billDetails.setBillnumber(rs.getInt("BILL_NUM"));
			billDetails.setConsumernum(rs.getInt("CONSUMER_NUM"));
			billDetails.setCurrentreading(rs.getInt("cur_reading"));
			billDetails.setUnitConsumed(rs.getInt("UNITCONSUMED"));
			billDetails.setNetamount(rs.getInt("NETAMOUNT"));
			billDetails.setBill_date(rs.getDate("BILL_DATE"));
			
			
				
			
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new MobileException(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new MobileException(e.getMessage());
		}
		return billDetails;
	}*/
	
	

	


