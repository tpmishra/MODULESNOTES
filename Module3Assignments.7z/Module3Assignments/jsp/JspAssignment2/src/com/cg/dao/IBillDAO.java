package com.cg.dao;

import java.util.List;




import com.cg.bean.BillDetails1;
import com.cg.bean.Consumer1;
import com.cg.mpa.exception.MobileException;

public interface IBillDAO 
{
	List<Consumer1>getConsumers1() throws MobileException;
	public Consumer1 getConsumer1(int id) throws MobileException;
	public List<BillDetails1> getBillDetails1(int cons_num) throws MobileException;
	//public BillDetails1 getBillDetail1(int id) throws MobileException;
	public BillDetails1 addBillDetails1(BillDetails1 billdetails) throws MobileException;
}
