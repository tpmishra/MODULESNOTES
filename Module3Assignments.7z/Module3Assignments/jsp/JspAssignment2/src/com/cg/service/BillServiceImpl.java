package com.cg.service;

import java.util.List;



import com.cg.bean.BillDetails1;
import com.cg.bean.Consumer1;
import com.cg.dao.BillDAOImpl;
import com.cg.dao.IBillDAO;
import com.cg.mpa.exception.MobileException;

public class BillServiceImpl implements IBillService 
{

	IBillDAO billDAO ;
	public BillServiceImpl() 
	{
		billDAO = new BillDAOImpl() ;
	}
	@Override
	public List<Consumer1> getConsumers1() throws MobileException {
		// TODO Auto-generated method stub
		return billDAO.getConsumers1();
	}
	@Override
	public Consumer1 getConsumer1(int id) throws MobileException {
		// TODO Auto-generated method stub
		return billDAO.getConsumer1(id);
	}
		public List<BillDetails1> getBillDetails1(int cons_num) throws MobileException
		{
			return billDAO.getBillDetails1(cons_num);
		}
		public BillDetails1 addBillDetails1(BillDetails1 billdetails) throws MobileException
		{
			return billDAO.addBillDetails1(billdetails);
		}
	}
	


