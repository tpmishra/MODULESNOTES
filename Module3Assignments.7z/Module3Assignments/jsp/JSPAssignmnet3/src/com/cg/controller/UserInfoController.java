package com.cg.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns={"/UserInfoController"})
public class UserInfoController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public UserInfoController() {
        super();
       
    }

	
	public void init(ServletConfig config) throws ServletException {
		
	}

	
	public void destroy() {
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String path=request.getServletPath();
		String url1="";
		System.out.println(path);
		switch(path)
		{
		case "/UserInfoController":
			String uname=request.getParameter("txtUN");
			String age=request.getParameter("txtAge");
			String url=request.getParameter("txtUrl");
			System.out.println(uname);
			request.setAttribute("username",uname);
			request.setAttribute("age", Integer.parseInt(age));
			request.setAttribute("url", url);
			url1="UserDetails.jsp";
			break;
			
		}
		RequestDispatcher rd=request.getRequestDispatcher(url1);
		rd.forward(request, response);
	
	}

}
