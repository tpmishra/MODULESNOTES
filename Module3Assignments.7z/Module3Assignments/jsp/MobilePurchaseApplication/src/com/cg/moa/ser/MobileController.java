package com.cg.moa.ser;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;
import com.cg.mpa.service.IMobileService;
import com.cg.mpa.service.MobileServiceImpl;


@WebServlet(urlPatterns={"/home","/Buy","/purchase"})
public class MobileController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String path = request.getServletPath();
		String url = "";
		HttpSession sess;
		IMobileService mser = new MobileServiceImpl();
		System.out.println(path);
		try {
			switch(path){
			case "/home":
					List<Mobile> mlist = mser.getMobiles();
					request.setAttribute("mlist", mlist);
					url = "Home.jsp";
					break;
			case "/Buy":
				int mid = Integer.parseInt(request.getParameter("mid"));
				 sess = request.getSession(true);
				sess.setAttribute("mid", mid);
				url="Insert.jsp";
				break;
			case "/purchase":
				PurchaseDetails pdetails = new PurchaseDetails();
				pdetails.setCname(request.getParameter("cname"));
				pdetails.setMailid(request.getParameter("mailid"));
				pdetails.setPhoneno(request.getParameter("phoneno"));
				String dateStr = request.getParameter("purchaseDate");
				DateTimeFormatter fomat = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				pdetails.setPurchaseDate(LocalDate.parse(dateStr, fomat));
				sess = request.getSession(false);
				pdetails.setMobileid((Integer)sess.getAttribute("mid"));
				int pid = mser.insertPurchase(pdetails);
				request.setAttribute("pdetails", pdetails);
				url = "Success.jsp";
			}
		} catch (MobileException e) {
			request.setAttribute("error", e.getMessage());
			url = "Error.jsp";
			
		}catch(Exception e)
		{
			request.setAttribute("error", e.getMessage());
			url = "Error.jsp";
		}
		RequestDispatcher disp = request.getRequestDispatcher(url);
		disp.forward(request, response);
	}

}
