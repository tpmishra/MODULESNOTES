package com.cg.mpa.service;

import java.util.List;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;

public interface IMobileService {
	List<Mobile>getMobiles() throws MobileException;
	int insertPurchase(PurchaseDetails pdetails) throws MobileException;

}
