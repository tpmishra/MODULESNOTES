package com.cg.mpa.exception;

public class MobileException extends Exception {
	
	public MobileException()
	{
		
	}
	public MobileException(String message)
	{
		super(message);
	}

}
