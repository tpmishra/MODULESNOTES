package com.cg.mpa.service;

import java.util.List;

import com.cg.mpa.dao.IMobileDao;
import com.cg.mpa.dao.MobileDaoImpl;
import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;

public class MobileServiceImpl implements IMobileService {
	IMobileDao mdao = new MobileDaoImpl();
	@Override
	public List<Mobile> getMobiles() throws MobileException {
		// TODO Auto-generated method stub
		return mdao.getMobiles();
	}

	@Override
	public int insertPurchase(PurchaseDetails pdetails) throws MobileException {
		// TODO Auto-generated method stub
		return mdao.insertPurchase(pdetails);
	}

}
