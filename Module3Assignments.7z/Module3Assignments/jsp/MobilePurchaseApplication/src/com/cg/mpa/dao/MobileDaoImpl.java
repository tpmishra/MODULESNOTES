package com.cg.mpa.dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;
import com.cg.mpa.util.DButil;

public class MobileDaoImpl implements IMobileDao {
	
	@Override
	public List<Mobile> getMobiles() throws MobileException {
		// TODO Auto-generated method stub
		Connection conn = null;
		String sql = "select * from mobiles";
		List<Mobile> mlist = new ArrayList<>();
		
			try {
				conn = DButil.getConnection();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		try{
			
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while(rs.next())
			{
				Mobile m = new Mobile();
				
				
				m.setMobileid(rs.getInt("mobileid"));
				m.setName(rs.getString("name"));
				m.setPrice(rs.getDouble("price"));
				m.setQuantity(rs.getInt("quantity"));
				mlist.add(m);
			}
		} catch (SQLException e) {
			throw new MobileException("Problem in fetching data"+e.getMessage());
		}
		return mlist;
	}
	
	private int fetchPurchaseId() throws MobileException{
		Connection conn = null;
		String sql = "select seq_purchaseid1.NEXTVAL from dual";
		int pid;
		try {
			conn = DButil.getConnection();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try
		{
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			pid = rs.getInt(1);
		}
		catch(Exception e)
		{
			throw new MobileException("Problem in fetching data"+e.getMessage());
		}
		return pid;
	}

	@Override
	public int insertPurchase(PurchaseDetails pdetails) throws MobileException {
		// TODO Auto-generated method stub
		
		Connection conn = null;
			String	sql = "Insert into purchasedetails values(?,?,?,?,?,?)";
             pdetails.setPurchaseid(fetchPurchaseId());

				
					try {
						conn = DButil.getConnection();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				
			
		
		try{
			
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, pdetails.getPurchaseid());
			pst.setString(2, pdetails.getCname());
			pst.setString(3, pdetails.getMailid());
			pst.setString(4, pdetails.getPhoneno());
			pst.setDate(5, Date.valueOf(pdetails.getPurchaseDate()));
			pst.setInt(6, pdetails.getMobileid());
			pst.executeUpdate();
		} catch (SQLException e)
		{
			// TODO Auto-generated catch block
			throw new MobileException("Problem in inserting data"+e.getMessage());
		}
		
		
		return pdetails.getPurchaseid();
	}

}
