CREATE TABLE employee_master
( 
	Emp_num NUMBER(4) PRIMARY KEY, 
	Emp_name VARCHAR2(25) NOT NULL,
	Dept_num NUMBER(2),  
	Salary NUMBER(9,2), 
 	Location VARCHAR2(30)  
); 

select * from employee_master ;

INSERT INTO employee_master VALUES(1001,'Smith',10, 5000,'Pune'); 
INSERT INTO employee_master VALUES(1002,'Venkat',30, 7800,'Chennai'); 
INSERT INTO employee_master VALUES(1003,'Meerah',20, 9000,'Surat'); 
INSERT INTO employee_master VALUES(1004,'Saniya',30, 8000,'Noida'); 
INSERT INTO employee_master VALUES(1005,'Shivam',30, 8500,'Noida'); 
INSERT INTO employee_master VALUES(1006,'Kiran',10, 6000,'Pune');