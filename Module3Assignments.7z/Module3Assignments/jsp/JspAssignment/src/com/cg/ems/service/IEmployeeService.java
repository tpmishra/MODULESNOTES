package com.cg.ems.service;

import java.util.List;

import com.cg.ems.bean.Employee;
import com.cg.ems.exception.EmployeeException;

public interface IEmployeeService 
{
	public Employee getEmployee(int empno) throws EmployeeException ;
	List<Employee> getEmployeeByName(String name) throws EmployeeException ;
	List<Employee> getEmployeeByDeptNo(int deptno) throws EmployeeException ;
	List<Employee> getEmployeeByLocation(String location) throws EmployeeException ;
}
