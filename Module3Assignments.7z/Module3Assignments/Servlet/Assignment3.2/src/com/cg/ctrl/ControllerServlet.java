package com.cg.ctrl;

import java.io.IOException;
import java.io.PrintWriter;
//import java.util.ArrayList;


import java.util.ArrayList;


import javax.servlet.RequestDispatcher;
//import javax.servlet.RequestDispatcher;
//import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.User;
import com.cg.service.IUserService;
import com.cg.service.UserService;



@WebServlet(name="ControllerServlet",urlPatterns={"/ControllerServlet"})
public class ControllerServlet extends HttpServlet {
	ServletConfig conf;
	IUserService uService = new UserService();
	private static final long serialVersionUID = 1L;
       
   
    public ControllerServlet() {
        super();
       
    }

	
	public void init(ServletConfig config) throws ServletException {
		conf = config;
		System.out.println("Init of controller servlet");
	}

	
	public void destroy() {
		System.out.println("destroy of controller servlet");
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("action");
		if(action!=null)
		{
			/***************ShowLoginPageAction****************/
			/*if(action.equals("ShowLoginPage"))
			{
				RequestDispatcher rdLog = request.getRequestDispatcher("/Login.html");
				rdLog.forward(request, response);
			}*/
			/****Validate user action***/
			/*if(action.equals("ValidateUser"))
			{
				String un = request.getParameter("txtunm");
				String pw = request.getParameter("txtpwd");
				User log = new User(un,pw);
				request.setAttribute("LogDetailsObj", log);
				RequestDispatcher rdVal = request.getRequestDispatcher("/ValidationServlet");
				rdVal.forward(request, response);
			}*/
			/************Insert user**************/
			if(action.equals("InsertUser"))
			{
				String fn =request.getParameter("txtname");
				String ln = request.getParameter("Ftxtname");
				String pw = request.getParameter("txtpd");
				String gn = request.getParameter("Gender");
				String ss = request.getParameter("chklk");
				String ci = request.getParameter("city");
				User user = new User(fn,ln,pw,gn,ss,ci);
				//int dataIns = uService.insertUser(new User(fn,ln,pw,gn,ss,ci));
				int id = uService.insertUser(user);
				//RequestDispatcher rd =request.getRequestDispatcher("pass.html");
				//rd.forward(request, response);
			
				
				if(id==1)
				{
				/*	ArrayList<User> uL=uService.getAllUsers();
					request.setAttribute("UListObj", uL);
					RequestDispatcher rd =request.getRequestDispatcher("/DisplayAllUserServlet");
					rd.forward(request, response);*/
					response.sendRedirect("/Assignment3.2/Success.html");
				}
			}
			
		}
		else
		{
			//PrintWriter pw = response.getWriter();
			//pw.println("No Action Defined..");
			response.sendRedirect("/Assignment3.2/Fail.html");
		}
		
		}
	}


