package com.cg.datew;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DateTimeServlet
 */
@WebServlet("/DateTimeServlet")
public class DateTimeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public DateTimeServlet() {
        super();
       
    }

    public void init(ServletConfig config) throws ServletException {

    	System.out.println("Init for DateTimeServlet");

    	}

    	public void destroy() {

    	System.out.println("Destroy for DateTimeServlet");

    	}

    	protected void doGet(HttpServletRequest request,

    	HttpServletResponse response)

    	throws ServletException, IOException

    	{

    	doPost(request,response);

    	}

    	protected void doPost(HttpServletRequest request,

    	HttpServletResponse response)

    	throws ServletException, IOException

    	{

    	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

    	Date date = new Date();

    	System.out.println(dateFormat.format(date));

    	}

    	}

