package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.bean.User;
import com.cg.dbutil.dbutil;

public class UserDaoImpl implements IUserDao {
	Connection con;
	Statement st;
	PreparedStatement pst;
	java.sql.ResultSet rs;


	@Override
	public int insertUser(User user) {
		try {
			con=dbutil.getConnection();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String insertQury = "Insert into RegisteredUsers values(?,?,?,?,?,?)";
		int dataInserted=0;
		try
		{
			pst = con.prepareStatement(insertQury);
			pst.setString(1,user.getFirstname());
			pst.setString(2,user.getLastname());
			pst.setString(3, user.getPassword());
			pst.setString(4,user.getGender());
			pst.setString(5,user.getSkillset());
			pst.setString(6, user.getCity());
			
			dataInserted=pst.executeUpdate();
			System.out.println("Data inserted successfully");
		}
		catch(Exception e)

		{
			e.printStackTrace();
		}
		finally
		{
			try{
				pst.close();
				con.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return dataInserted;
		
	}


	@Override
	public ArrayList<User> getAllUsers() {
		// TODO Auto-generated method stub
		ArrayList<User> uList = new ArrayList<User>();
		try {
			con=dbutil.getConnection();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try{
			
		
		st = con.createStatement();
		rs=st.executeQuery("select * from RegisteredUsers");
		while(rs.next())
		{
			User u = new User(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
			uList.add(u);
		}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try{
				st.close();
				rs.close();
				con.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
		return uList;
		
	}
	}
		
		
	


