package com.cg.page;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.User;

/**
 * Servlet implementation class DisplayAllUserServlet
 */
@WebServlet("/DisplayAllUserServlet")
public class DisplayAllUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public DisplayAllUserServlet() {
        super();
       
    }

	
	public void init(ServletConfig config) throws ServletException {
	
	}

	
	public void destroy() {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		ArrayList<User> userList = (ArrayList) request.getAttribute("UListObj");
		pw.println("<table border = '1'>");
		for(User tempU:userList)
		{
			pw.println("<tr>");
			pw.println("<td>"+tempU.getFirstname()+"</td>");
			pw.println("<td>"+tempU.getLastname()+"</td>");
			pw.println("<td>"+tempU.getPassword()+"</td>");
			pw.println("<td>"+tempU.getGender()+"</td>");
			pw.println("<td>"+tempU.getSkillset()+"</td>");
			pw.println("<td>"+tempU.getCity()+"</td>");
			
			pw.println("</tr>");
		}
	}

}
