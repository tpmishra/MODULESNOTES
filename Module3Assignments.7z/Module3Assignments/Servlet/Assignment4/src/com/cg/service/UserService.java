package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.User;
import com.cg.dao.IUserDao;
import com.cg.dao.UserDaoImpl;


public class UserService implements IUserService{
	IUserDao userDao;
	public UserService()
	{
		userDao=new UserDaoImpl();
	}


	@Override
	public int insertUser(User user) {
		// TODO Auto-generated method stub
		return userDao.insertUser(user);
	}


	@Override
	public ArrayList<User> getAllUsers() {
		// TODO Auto-generated method stub
		return userDao.getAllUsers();
	}

}
