

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/NextPage")
public class NextPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
    public NextPage() {
        super();
       
    }

	public void init(ServletConfig config) throws ServletException {
		
	}

	public void destroy() {
	
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String status=request.getParameter("remember");
		System.out.println(status);
		if(status!=null)
		{
			Cookie cookie=new Cookie("status",status);
			 cookie.setMaxAge(24*60*60);
			response.addCookie(cookie);
			
		}
		response.sendRedirect("Login.html");
	}

}
