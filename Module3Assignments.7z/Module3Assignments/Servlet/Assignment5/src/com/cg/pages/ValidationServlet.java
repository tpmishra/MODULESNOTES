package com.cg.pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.cg.beans.Consumers;
import com.cg.service.ConsumerServiceImpl;
import com.cg.service.IConsumerService;


@WebServlet("/ValidationServlet")
public class ValidationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IConsumerService consumerService;
	
       
   
    public ValidationServlet() {
        super();
        consumerService = new ConsumerServiceImpl();
    }

	
	public void init(ServletConfig config) throws ServletException {
		
	}

	
	public void destroy() {
		// TODO Auto-generated method stub
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String consumerNum = (String) request.getAttribute("consumer_Num");
		//String lastMR = (String) request.getAttribute("lastMR") ;
		//String currentMR = (String) request.getAttribute("currentMR") ;
		
		int consNum = Integer.parseInt(consumerNum) ;
		if(consumerService.isConsumersExist(consNum))
		{
			Consumers consumer = consumerService.getConsumersDetails(consNum) ;
		
			if(consumer!= null)
			{
				RequestDispatcher rdSucc = request.getRequestDispatcher("/CalculateBill") ;
				rdSucc.forward(request, response);
			}
		}
		else
		{
			PrintWriter out = response.getWriter() ;
			out.println("Register");
	}
	}
}


