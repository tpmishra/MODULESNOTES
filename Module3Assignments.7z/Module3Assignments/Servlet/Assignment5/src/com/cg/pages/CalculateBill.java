package com.cg.pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.beans.BillDetails;
import com.cg.service.ConsumerServiceImpl;
import com.cg.service.IConsumerService;


@WebServlet("/CalculateBill")
public class CalculateBill extends HttpServlet {
	private static final long serialVersionUID = 1L;
     int FIXED_CHARGE = 100;
     BillDetails billDetails;
     IConsumerService consumerService;
    
    public CalculateBill() {
        consumerService = new ConsumerServiceImpl();
        
    }

	public void init(ServletConfig config) throws ServletException {
		
	}

	
	public void destroy() {
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String consNum = (String) request.getAttribute("consumer_Num");
		String lmr = (String) request.getAttribute("lmr");
		String cmr = (String) request.getAttribute("cmr");
		int consNumber = Integer.parseInt(consNum);
		int lastMR = Integer.parseInt(lmr);
		int currentMR = Integer.parseInt(cmr);
		if(currentMR > lastMR)
		{
			int unitConsumed = currentMR - lastMR;
			int netamount = (int) (unitConsumed * 1.15 + FIXED_CHARGE);
			billDetails = new BillDetails();
			billDetails.setConsumer_num(consNumber);
			billDetails.setCur_reading(currentMR);
			billDetails.setUnitConsumed(unitConsumed);
			billDetails.setNetAmount(netamount);
			Long millis = System.currentTimeMillis();
			java.sql.Date date = new Date(millis);
			billDetails.setBill_date(date);
			consumerService.insertBillDetails(billDetails);
			
			
		}
		else
		{
			PrintWriter out = response.getWriter();
			out.println("CurrentMeter reading should be greater than last month reading");
			
		}
	}

}
