package com.cg.ctrl;

import java.io.IOException;



import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.cg.service.IConsumerService;




@WebServlet(name="ControllerServlet",urlPatterns={"/ControllerServlet"})
public class ControllerServlet extends HttpServlet {
	
	IConsumerService uService;
	ServletConfig conf;
	private static final long serialVersionUID = 1L;
       
   
    public ControllerServlet() {
        super();
       
    }

	
	public void init(ServletConfig config) throws ServletException {
		conf = config;
		System.out.println("Init of controller servlet");
	}

	
	public void destroy() {
		System.out.println("destroy of controller servlet");
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("action");
		if(action!=null)
		{
			
			
			/****Validate user action***/
			if(action.equals("ValidateUser"))
			{
				String cn = request.getParameter("txtname");
				String lm = request.getParameter("txtnamel");
				String cm = request.getParameter("txtnamec");
				request.setAttribute("consumer_Num", cn);
				request.setAttribute("Lmr", lm);
				request.setAttribute("cmr", cm);
				RequestDispatcher rdVal = request.getRequestDispatcher("/ValidationServlet");
				rdVal.forward(request, response);
			}
			
			
		}
		/*else
		{
			PrintWriter pw = response.getWriter();
			pw.println("No Action Defined..");
		}
		*/
	}

}
