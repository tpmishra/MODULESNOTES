package com.cg.service;

import com.cg.beans.BillDetails;
import com.cg.beans.Consumers;

public interface IConsumerService {

	
	public boolean isConsumersExist(int unm);
	public Consumers getConsumersDetails(int un);
	public BillDetails insertBillDetails(BillDetails billdetails);
}
