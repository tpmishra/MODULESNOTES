package com.cg.service;

import com.cg.beans.BillDetails;
import com.cg.beans.Consumers;
import com.cg.dao.ConsumerDaoImpl;
import com.cg.dao.IConsumerDao;

public class ConsumerServiceImpl implements IConsumerService {
IConsumerDao consumerDao;
 public ConsumerServiceImpl() {
	consumerDao = new ConsumerDaoImpl();
}
	@Override
	public boolean isConsumersExist(int unm) {
		// TODO Auto-generated method stub
		return consumerDao.isConsumersExist(unm);
	}

	@Override
	public Consumers getConsumersDetails(int un) {
		// TODO Auto-generated method stub
		return consumerDao.getConsumersDetails(un);
	}

	@Override
	public BillDetails insertBillDetails(BillDetails billdetails) {
		// TODO Auto-generated method stub
		return consumerDao.insertBillDetails(billdetails);
	}

}
