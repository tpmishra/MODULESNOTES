package com.cg.beans;

import java.sql.Date;

public class BillDetails {
	
	private int bill_num;
	private int consumer_num;
	private int cur_reading;
	private int unitConsumed;
	private int netAmount;
	private Date bill_date;
	public int getBill_num() {
		return bill_num;
	}
	public void setBill_num(int bill_num) {
		this.bill_num = bill_num;
	}
	public int getConsumer_num() {
		return consumer_num;
	}
	public void setConsumer_num(int consumer_num) {
		this.consumer_num = consumer_num;
	}
	public int getCur_reading() {
		return cur_reading;
	}
	public void setCur_reading(int cur_reading) {
		this.cur_reading = cur_reading;
	}
	public int getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(int unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public int getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(int netAmount) {
		this.netAmount = netAmount;
	}
	public Date getBill_date() {
		return bill_date;
	}
	public void setBill_date(Date bill_date) {
		this.bill_date = bill_date;
	}
	public BillDetails(int bill_num, int consumer_num, int cur_reading,
			int unitConsumed, int netAmount, Date bill_date) {
		super();
		this.bill_num = bill_num;
		this.consumer_num = consumer_num;
		this.cur_reading = cur_reading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
		this.bill_date = bill_date;
	}
	public BillDetails() {
		super();
	}
	@Override
	public String toString() {
		return "BillDetails [bill_num=" + bill_num + ", consumer_num="
				+ consumer_num + ", cur_reading=" + cur_reading
				+ ", unitConsumed=" + unitConsumed + ", netAmount=" + netAmount
				+ ", bill_date=" + bill_date + "]";
	}
	

}
