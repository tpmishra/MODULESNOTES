package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import com.cg.beans.BillDetails;
import com.cg.beans.Consumers;
import com.cg.dbutil.dbutil;



public class ConsumerDaoImpl implements IConsumerDao{
	Connection con ;
	Statement stm ;
	PreparedStatement pstm ;
	ResultSet res ;
	@Override
	public boolean isConsumersExist(int unm) {
		boolean flag = false ;
		try
		{
			con = dbutil.getConnection() ;
			pstm = con.prepareStatement("select count(*) from consumers where consumer_num=? ") ;
			pstm.setInt(1, unm);
			res = pstm.executeQuery() ;
			res.next() ;
			int count = res.getInt(1) ;
			if( count==1 )
			{
				flag = true ;
			}
			else
			{
				flag = false ;
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				res.close();
				pstm.close();
				con.close();
			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			}
			
		}
		return flag;
	}
	
	

	@Override
	public Consumers getConsumersDetails(int un) {
		Consumers consumer = null ;
		try
		{
			con = dbutil.getConnection() ;
			pstm = con.prepareStatement("select * from consumers where consumer_num = ?") ;
			pstm.setInt(1, un);
			res = pstm.executeQuery() ;
			res.next() ;
			consumer = new Consumers() ;
			consumer.setConsumer_num(res.getInt("consumer_num"));
			consumer.setConsumer_name(res.getString("consumer_name"));
			consumer.setAddress(res.getString("address"));
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				res.close();
				pstm.close();
				con.close();
			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			}
			
		}
		return consumer;
	}
	

	@Override
	public BillDetails insertBillDetails(BillDetails billdetails) {
		// TODO Auto-generated method stub
		try
		{
			con = dbutil.getConnection() ;
			stm = con.createStatement() ;
			res = stm.executeQuery("select seq_bill_num.nextval from dual ") ;
			if(	res.next() == false )
			{
				
			}
			int id = res.getInt(1) ;
			
			String query = "insert into BillDetails values(?,?,?,?,?,?)" ;
			
			pstm = con.prepareStatement(query) ;
			pstm.setInt(1, id);
			pstm.setInt(2, billdetails.getConsumer_num());
			pstm.setInt(3, billdetails.getCur_reading());
			pstm.setInt(4, billdetails.getUnitConsumed());
			pstm.setDouble(5, billdetails.getNetAmount());
			pstm.setDate(6, billdetails.getBill_date());
			pstm.execute();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				pstm.close();
				con.close();
			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			}
			
		}

		return billdetails;
	}

	}


