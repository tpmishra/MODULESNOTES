package com.capgemini.gym.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotEmpty;



@Entity
@Table(name="CustomerDetails")
public class Customer 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "mygen")
	@SequenceGenerator(name="mygen", sequenceName="custidseq", initialValue=1000)
	private int id;
	
	@NotEmpty(message  = "Name cannot be empty")
	private String name;
	
	@Min(value=15, message = "Age cannot be less than 15")
	@Max(value=120, message = "Age cannot be more than 120")
	private int age;
	
	@NotEmpty(message = "Gym Name cannot be empty")
	private String gym;
	
	@NotEmpty(message = "You have to select atleast onetimings")
	private String timings;
	public Customer(String name, int age, String gym, String timings) {
		super();
		this.name = name;
		this.age = age;
		this.gym = gym;
		this.timings = timings;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(int id, String name, int age, String gym, String timings) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.gym = gym;
		this.timings = timings;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (id != other.id)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", age=" + age
				+ ", gym=" + gym + ", timings=" + timings + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGym() {
		return gym;
	}
	public void setGym(String gym) {
		this.gym = gym;
	}
	public String getTimings() {
		return timings;
	}
	public void setTimings(String timings) {
		this.timings = timings;
	}
}
