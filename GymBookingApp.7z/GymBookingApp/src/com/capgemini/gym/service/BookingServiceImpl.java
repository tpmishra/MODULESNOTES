package com.capgemini.gym.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.gym.dao.IBookingDAO;
import com.capgemini.gym.entities.Customer;
import com.capgemini.gym.exception.BookingException;


@Service
@Transactional
public class BookingServiceImpl implements IBookingService {

	@Autowired
	private IBookingDAO bookingDAO;

	public IBookingDAO getBookingDAO() {
		return bookingDAO;
	}

	public void setBookingDAO(IBookingDAO bookingDAO) {
		this.bookingDAO = bookingDAO;
	}

	public BookingServiceImpl(IBookingDAO bookingDAO) {
		super();
		this.bookingDAO = bookingDAO;
	}

	public BookingServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public int addCustomer(Customer customer) throws BookingException {
		// TODO Auto-generated method stub
		return bookingDAO.addCustomer(customer);
	}

	@Override
	public Customer getCustomer(int id) throws BookingException {
		// TODO Auto-generated method stub
		return bookingDAO.getCustomer(id);
	}
}
