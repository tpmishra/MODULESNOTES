package com.capgemini.gym.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.capgemini.gym.entities.Customer;
import com.capgemini.gym.exception.BookingException;


@Repository
public class BookingDaoImpl implements IBookingDAO {

	@PersistenceContext
	private EntityManager entityManager;

	public BookingDaoImpl(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}

	public BookingDaoImpl() {
		
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public int addCustomer(Customer customer) throws BookingException {
		// TODO Auto-generated method stub
		int bookingid = -1;
		try{
			entityManager.persist(customer);
			bookingid = customer.getId();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return bookingid;
		
	}

	@Override
	public Customer getCustomer(int id) throws BookingException {
		// TODO Auto-generated method stub
		Customer customer = null;
		try
		{
			customer = entityManager.find(Customer.class, id);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new BookingException(e.getMessage());
		}
		if(customer == null)
			throw new BookingException("Customer Not found");
		return customer;
	}
	
}
