package com.capgemini.gym.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.gym.entities.Customer;
import com.capgemini.gym.service.IBookingService;


@Controller
public class GymBookingController {
	
	@Autowired
	private IBookingService bookingService;

	public IBookingService getBookingService() {
		return bookingService;
	}

	public void setBookingService(IBookingService bookingService) {
		this.bookingService = bookingService;
	}

	public GymBookingController() {
		
	}

	public GymBookingController(IBookingService bookingService) {
		super();
		this.bookingService = bookingService;
	}

	@RequestMapping("addCustomer")
	public String  AddCustomerPage(Model model)
	{
		List<String> gymNames = new ArrayList<>();
		gymNames.add("GoldGym");
		gymNames.add("Tawalkars");
		gymNames.add("Silver Gym");
		gymNames.add("TALWADEGYM");
		
		List<String> timings = new ArrayList<>();
		timings.add("Morning");
		timings.add("AfterNoon");
		timings.add("Evenening");
		timings.add("Night");
		model.addAttribute("gymNames", gymNames);
		model.addAttribute("timings", timings);
		model.addAttribute("customer", new Customer());
		return "AddCustomerPage";
	}
	
	@RequestMapping(value = "addcustom", method = RequestMethod.POST)
	public String AddCustom(@ModelAttribute("customer") @Valid Customer customer,BindingResult result, Model model)
	{
		if(result.hasErrors())
		{
			
		
		List<String> gymNames = new ArrayList<>();
		gymNames.add("GoldGym");
		gymNames.add("Tawalkars");
		gymNames.add("Silver Gym");
		gymNames.add("TALWADEGYM");
		
		List<String> timings = new ArrayList<>();
		timings.add("Morning");
		timings.add("AfterNoon");
		timings.add("Evenening");
		timings.add("Night");
		model.addAttribute("gymNames", gymNames);
		model.addAttribute("timings", timings);
		model.addAttribute("customer", customer);
		return "AddCustomerPage";
	}
		int ID = -1;
		try
		{
			ID = bookingService.addCustomer(customer);
		}
	catch(Exception e)
		{
		e.printStackTrace();
		model.addAttribute("errMsg", "Something went wrong while adding customer");
		return "ErrorPage";
		}
		model.addAttribute("successmsg","Customer added Successfully"+ID);
		return "SuccessPage";
	
}
@RequestMapping("ViewCustomer")
public String getCustomerPage()
{
	return "GetCustomerPage";
}

@RequestMapping (value ="processview", method=RequestMethod.POST)
public String processView(@RequestParam("CustomerId") int id, Model model)
{
	Customer customer = null;
	try
	{
		customer = bookingService.getCustomer(id);
	}
	catch(Exception e)
	{
	e.printStackTrace();
	model.addAttribute("errMsg", "Something went wrong while adding customer");
	return "ErrorPage";
	}
	model.addAttribute("customer", customer);
	return "GetCustomerPage";
}






}
