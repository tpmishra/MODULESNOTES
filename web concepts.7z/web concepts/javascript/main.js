function displayDetails(form1)

{

if(form1.checkValidity())

{

if(form1[0].value!="" || form1[1].value!="" || form1[2].value!="" || form1[3].value!="" )

{

var win=window.open("","Preview","width=800,height=800");

win.document.write("<html><head><title>Products table</title></head><body><table border=1>");

win.document.write("<th>Name</th>");

win.document.write("<th>Description</th>");

win.document.write("<th>Price</th>");

win.document.write("<th>Quantity</th>");

win.document.write("<th>Total Price</th></tr>");

if(form1[0].value!="")

{

win.document.write("<tr><td>Barbie Doll</td>");

win.document.write("<td>Beautiful</td>");

win.document.write("<td>20</td>");

win.document.write("<td>"+form1[0].value+"</td>");

var qty=form1[0].value;

var price=20;

var totalprice=qty*price;

win.document.write("<td>"+totalprice+"</td>");

}

if(form1[1].value!="")

{

win.document.write("<tr><td>Calculator</td>");

win.document.write("<td>Calculator witjh latest features</td>");

win.document.write("<td>30</td>");

win.document.write("<td>"+form1[1].value+"</td>");

var qty=form1[1].value;

var totalprice=qty*30;

win.document.write("<td>"+totalprice+"</td>");

}

if(form1[2].value!="")

{

win.document.write("<tr><td>Mobile Phone</td>");

win.document.write("<td>Camera,Java Games,GPRS</td>");

win.document.write("<td>40</td>");

win.document.write("<td>"+form1[2].value+"</td>");

var qty=form1[2].value;

var totalprice=qty*40;

win.document.write("<td>"+totalprice+"</td>");

}

if(form1[3].value!="")

{

win.document.write("<tr><td>LG DVD</td>");

win.document.write("<td>5 disc changer</td>");

win.document.write("<td>50</td>");

win.document.write("<td>"+form1[3].value+"</td>");

var qty=form1[3].value;

var price=50;

var totalprice=qty*50;

win.document.write("<td>"+totalprice+"</td>");

win.document.write("</table></body></html>");

}

}

else

{

alert('Quantity not Filled');

}

}
}