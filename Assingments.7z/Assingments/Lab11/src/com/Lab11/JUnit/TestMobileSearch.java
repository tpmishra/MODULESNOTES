package com.Lab11.JUnit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.Lab11.dao.IMobileDao;
import com.Lab11.dao.MobileDaoImpl;
import com.Lab11.exception.MobileException;

public class TestMobileSearch {

	IMobileDao iMobile;
	@Before
	public void setUp() throws Exception {
		iMobile= new MobileDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSearchByRange() throws MobileException {
		 assertTrue(iMobile.updateQty(1001, 1));
	}

}
