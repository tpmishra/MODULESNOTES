package com.Lab11.services;

import java.util.List;

import com.Lab11.bean.Mobile;
import com.Lab11.exception.MobileException;

public interface IMobileService {

	public List<Mobile> showAllMobiles() throws MobileException;
	public boolean deleteMobile(int mid) throws MobileException;
	public List<Mobile> searchMobile(int start,int end) throws MobileException;
	public boolean updateQty(int mobileId, int quantity) throws MobileException;
	
	
}
