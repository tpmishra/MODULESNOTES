package com.Lab11.services;

import com.Lab11.bean.Purchase;
import com.Lab11.exception.MobileException;



public interface IPurchaseService {
	public boolean addPurchaseDetail(Purchase purchase) throws MobileException;
}
