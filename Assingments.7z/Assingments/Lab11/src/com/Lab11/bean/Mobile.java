package com.Lab11.bean;

public class Mobile {

	private int mobileid;
	private String name;
	private double price;
	private int quatity;
	public Mobile(int mobileid, String name, double price, int quatity) {
		super();
		this.mobileid = mobileid;
		this.name = name;
		this.price = price;
		this.quatity = quatity;
	}
	public Mobile() {
		super();
	}
	public int getMobileid() {
		return mobileid;
	}
	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuatity() {
		return quatity;
	}
	public void setQuatity(int quatity) {
		this.quatity = quatity;
	}
	@Override
	public String toString() {
		return "Mobile [mobileid=" + mobileid + ", name=" + name + ", price="
				+ price + ", quatity=" + quatity + "]";
	}
	

	
	
}
