package com.Lab11.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;

import org.apache.log4j.Logger;

import com.Lab11.bean.Mobile;
import com.Lab11.bean.Purchase;
import com.Lab11.exception.MobileException;
import com.Lab11.util.JdbcUtil;


public class PurchaseDaoImpl implements IPurchaseDao{

	Connection con;
	PreparedStatement ps;
	ResultSet rs;
	//Purchase p = new Purchase();
	//PurchaseDaoImpl pd=new PurchaseDaoImpl();
	private static final Logger mylogger = Logger
			.getLogger(PurchaseDaoImpl.class);
	public boolean insertPurchaseDetails(Purchase p) throws MobileException {
		int rec=0;
		String query="Insert into purchasedetails values(seq_id.NEXTVAL,?,?,?,sysdate,?)";
		
		try {
			con = JdbcUtil.getConnection();
			ps=con.prepareStatement(query);
			ps.setString(1,p.getcName());
			ps.setString(2,p.getMailId());
			ps.setString(3,p.getPhoneNo());
			ps.setInt(4, p.getMobileId());
			rec=ps.executeUpdate();
			if(rec>0)
			{
				return true;
			}
		
		
		mylogger.info("Data inserted");
		
		
		} catch (MobileException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e) {
			mylogger.error("Data not inserted");
			e.printStackTrace();
		}
	return false;
	}

			
		}
	
	/*public int getPurchaseId(){
		int p_id=0;
		try {
			con = JdbcUtil.getConnection();
		} catch (MobileException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String query ="select purchase_seq.nextval from dual";
		try {
			ps = con.prepareStatement(query);
			rs = ps.executeQuery();
			while (rs.next()) {
				 p_id = rs.getInt(1);
				p.setPurchaseId(p_id);
		} 
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return p_id;
	}*/
		
	
		
/*	public static void main(String args[]){
		IPurchaseDao p = new PurchaseDaoImpl();
		Purchase p1 = new Purchase();
		// Purchase();
		purchase.setcName("Namugoru");
		purchase.setMailId("mrun@g.com");
		purchase.setMobileId("1005");
		purchase.setPhoneNo("9874561231");
		purchase.setPurchaseId(10);
		purchase.setPurchaseDate(purchase.getPurchaseDate());
		p.insertPurchaseDetails(purchase);
		 Purchase purchase=new Purchase(10, "Namuuu","mrun@gmail.com","9874563211",  p1.getPurchaseDate(),"1003");
		 p.insertPurchaseDetails(purchase);
		System.out.println("Inserted");
	}*/
	


