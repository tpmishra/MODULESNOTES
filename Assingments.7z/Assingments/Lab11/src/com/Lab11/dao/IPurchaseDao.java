package com.Lab11.dao;

import com.Lab11.bean.Purchase;
import com.Lab11.exception.MobileException;

public interface IPurchaseDao {

	public boolean insertPurchaseDetails(Purchase p) throws MobileException;
	
	
}
