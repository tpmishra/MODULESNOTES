package com.Lab11.dao;

import java.util.List;

import com.Lab11.bean.Mobile;
import com.Lab11.exception.MobileException;

public interface IMobileDao {

	List<Mobile> showAll() throws MobileException;
	boolean deleteMobile(int mobileId) throws MobileException;
	List<Mobile> searchByRange(int start,int end) throws MobileException;
	boolean updateQty(int mobileId,int quantity) throws MobileException;
}
