package com.Lab11.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.Lab11.bean.Mobile;
import com.Lab11.exception.MobileException;
import com.Lab11.util.JdbcUtil;

public class MobileDaoImpl implements IMobileDao {

	Connection con;
	PreparedStatement ps;
	ResultSet rs;
	Mobile m = new Mobile();
	private static final Logger mylogger = Logger
			.getLogger(MobileDaoImpl.class);

	public List<Mobile> showAll() throws MobileException {
		con = JdbcUtil.getConnection();
		String query = "SELECT * FROM MOBILES";
		List<Mobile> mList = new ArrayList<Mobile>();
		try {
			mylogger.info("Successful");
			ps = con.prepareStatement(query);
			rs = ps.executeQuery();
			while (rs.next()) {
				int m_id = rs.getInt(1);
				String m_name = rs.getString(2);
				double m_price = rs.getDouble(3);
				int m_quantity = rs.getInt(4);

				Mobile m = new Mobile();

				m.setMobileid(m_id);
				m.setName(m_name);
				m.setPrice(m_price);
				m.setQuatity(m_quantity);
				mList.add(m);
				mylogger.info("Successful");
			}

		} catch (SQLException e) {
			mylogger.error("Not successful");
			e.printStackTrace();
			throw new MobileException("Data not found");
		} finally {
			try {
				rs.close();
				ps.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
		}

		return mList;
	}

	public boolean deleteMobile(int mobileId) throws MobileException {
		con = JdbcUtil.getConnection();
		String query = "DELETE FROM  MOBILES WHERE mobileid=?";
		int rec = 0;
		try {
			ps = con.prepareStatement(query);
			ps.setInt(1, mobileId);
			rec = ps.executeUpdate();
			mylogger.info("Successfully deleted");

		} catch (SQLException e) {
			mylogger.error("Data not deleted");
			
			e.printStackTrace();
			throw new MobileException("Data not found");
		} finally {
			try {
				ps.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (rec > 0) {
			return true;
		} else {

			return false;
		}
	}

	public List<Mobile> searchByRange(int start, int end)
			throws MobileException {
		con = JdbcUtil.getConnection();
		String query = "SELECT * FROM MOBILES WHERE price>=? AND price<=?";
		List<Mobile> mList = new ArrayList<Mobile>();
		try {
			ps = con.prepareStatement(query);
			ps.setInt(1, start);
			ps.setInt(2, end);
			rs = ps.executeQuery();

			while (rs.next()) {
				int m_id = rs.getInt(1);
				String m_name = rs.getString(2);
				double m_price = rs.getDouble(3);
				int m_quantity = rs.getInt(4);

				Mobile m = new Mobile();

				m.setMobileid(m_id);
				m.setName(m_name);
				m.setPrice(m_price);
				m.setQuatity(m_quantity);
				mList.add(m);
				mylogger.info("Succesfully searched");
			}
		} catch (SQLException e) {
			mylogger.error("Unable to search");
			e.printStackTrace();
			throw new MobileException("Data not found");
		} finally {
			try {
				rs.close();
				ps.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return mList;

	}

	// for manual testing
	/*
	 * public static void main(String args[]){ MobileDaoImpl impl = new
	 * MobileDaoImpl(); //List<Mobile>mList = impl.showAll();
	 * //List<Mobile>mList = impl.searchByRange(8000, 15000); for(Mobile
	 * m:mList){ System.out.println(m); }
	 * //System.out.println(impl.deleteMobile(1001));
	 */

	public boolean updateQty(int mobileId, int quantity)
			throws MobileException {
		con = JdbcUtil.getConnection();
		String query = "UPDATE MOBILES SET QUANTITY=QUANTITY-? WHERE mobileid=?";

		try {
			ps = con.prepareStatement(query);
			ps.setInt(1, quantity);
			ps.setInt(2, mobileId);
			int rec = ps.executeUpdate();
			if (rec > 0) {
				return true;
			}
			mylogger.info("Updated successfully");
		} catch (SQLException e) {
			mylogger.error("Data not updated");
			e.printStackTrace();
			throw new MobileException("Data not found");
		} finally {
			try {
				ps.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return false;
	}

}
