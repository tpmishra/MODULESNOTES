package lab3_6;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;


public class Zone 
{
	


	public void zone(String zone)

	{

	ZonedDateTime currentTime = ZonedDateTime.now(ZoneId.of(zone));

	System.out.println("Current Time in " + zone + " is " + currentTime);

	}

	public static void main(String [] args)

	{

	Zone zd = new Zone();

	Scanner sc = new Scanner(System.in);

	System.out.println("Enter Zone in given pattern");

	System.out.println("1. America/New_York");

	System.out.println("2. Europe/London ");

	System.out.println("3. Asia/Tokyo ");

	System.out.println("4. US/Pacific ");

	System.out.println("5. Africa/Cairo ");

	System.out.println("6. Australia/Sydney ");

	String zoneid = sc.next();

	sc.close();

	zd.zone(zoneid);

	}

}

