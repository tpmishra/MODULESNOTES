package lab3_5;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.sql.Date;

public class Product
{
	



	public static void main(String[] args) {

	// TODO Auto-generated method stub

	Scanner sc=new Scanner(System.in);

	System.out.println("Enter Product Purchase Date in DD-MM-YY format:");

	String input = sc.nextLine();

	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");

	System.out.println("Enter Warranty in years:");

	String warranty = sc.nextLine();

	LocalDate start = LocalDate.parse(input,formatter);



	LocalDate end = LocalDate.now();

	Period period = start.until(end);

	System.out.println("Days:"+ period.getDays());

	System.out.println("Months:"+period.getMonths());

	System.out.println("Years:"+ period.getYears());

	}

}
	

