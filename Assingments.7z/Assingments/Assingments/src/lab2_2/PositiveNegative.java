package lab2_2;

public class PositiveNegative {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			int num =Integer.parseInt(args[0]);
			
			if(num>0)
			{
				System.out.println("Number Is Positive");
			}
			
			else if (num<0)
			{
				System.out.println("Number Is Negative");
			}
			else
			{
				System.out.println("Number Is Neither Positive Nor Negative");
			}
	
			
			
	}

}
