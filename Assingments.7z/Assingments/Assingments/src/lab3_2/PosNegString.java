package lab3_2;
import java.util.Scanner;

public class PosNegString {


	public static void main(String args[])

	{

	String str;

	Scanner sc = new Scanner(System.in);

	System.out.println("Enter a String:");

	str=sc.next();

	boolean b=false;

	char[] ch=str.toCharArray();

	char c1=' ';

	char c2=' ';

	for(int i=0;i<str.length();i++)

	{

		c1=ch[i];

		for(int j=1;j<str.length();j++)

			{

					c2=ch[j];

			}

		if(c1>c2)

			{

				b=true;

			}

	}

		if(b==false)

		{

			System.out.println("String is positive");
			
		}
		
		else

		{

			System.out.println("String is negative");

		}

	}

	}