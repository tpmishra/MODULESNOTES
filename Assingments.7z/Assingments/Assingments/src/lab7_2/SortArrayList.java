package lab7_2;

import java.util.ArrayList;
import java.util.Collections;


public class SortArrayList
{

	public static void main(String [] args)

	{

		ArrayList<String> prodlist = new ArrayList<String>();

		prodlist.add("Pen");

		prodlist.add("Pencil");

		prodlist.add("Eraser");
	
		prodlist.add("Compasss Box");

		Collections.sort(prodlist);

	for(String pr :prodlist)

		{

			System.out.println(pr);

		}

	}

}


