package lab9_2;

public class Date
{
	int intDay, intMonth, intYear;
	
	Date(int intDay, int intMonth, int intYear)
	
	{
		this.intDay = intDay;
		this.intMonth = intMonth;
		this.intYear = intYear;
	
	}
	
	
	void setDay(int intDay)
	{
		this.intDay = intDay;
	}
	
	int getDay( )
	{
		return this.intDay;
	}
	
	void setMonth(int intMonth)
	{
		this.intMonth = intMonth;
	}
	
	int getMonth( )
	{
		return this.intMonth;
	}
	
	void setYear(int intYear)
	{
		this.intYear=intYear;
	}
	
	int getYear( )
	{
		
		return this.intYear;
	}
	@Override
	public String toString() 
	{
		return "Date [intDay=" + intDay + ", intMonth=" + intMonth
				+ ", intYear=" + intYear + "]";
	}
	
	public static void main(String args[])
	
	{
		Date d = new Date(7,9,1994);
		
		System.out.println(d.getDay()+" "+d.getMonth()+" "+d.getYear());
	}
	} // Date class

