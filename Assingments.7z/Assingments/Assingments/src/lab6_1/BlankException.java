package lab6_1;

public class BlankException extends Exception{

	public BlankException()
	{
		System.out.println("Please Fill The Values");
	}
}
