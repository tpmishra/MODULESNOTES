package lab6_1;

import java.util.*;

public class Funct {

	public static void main(String[] args) throws BlankException {
	
	/*	Person p = new Person();
		
		p.setFirstName("");
		p.setLastName(""); */
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter First Name");
		String fn = sc.nextLine();
		
		System.out.println("Enter Last Name");
		
		String ln = sc.nextLine();
	
		try
	
		{
			String f = fn;
			String l = ln;
			if(fn.isEmpty() || ln.isEmpty() )
			{
	
				throw new BlankException();
				
			}
		}	
			
			
		
		finally
		{
			System.out.println(fn+" "+ln);
			
		}
			

	}

}
