package lab4_Total;


public class SavingAccount extends Account {

	private double minBalance;

	public double getMinBalance() {
		return minBalance;
	}

	public void setMinBalance(double minBalance) {
		this.minBalance = minBalance;
	}

	public SavingAccount(double minBalance) {
		super();
		this.minBalance = minBalance;
	}

	public SavingAccount(long accountNo, double balance, Person person,double minBalance) {
		super(accountNo, balance, person);
		
		this.minBalance = minBalance;
		
			
		
	}
	public void withdraw(double amount){
		
		if(getBalance()-amount>minBalance)
		{
			
			setBalance(getBalance()-amount);
			System.out.println("Amount Drawn Successfully from saving account");
		}
	}
	
	
	
}

