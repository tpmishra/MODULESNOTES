package lab2_4;

import lab2_3.Person;



public class PersonDetailsDemo {

	public static void main(String[] args) {
	


		PersonDetails p; 
		p = new PersonDetails("Suraj","Parmar",7894561233l);
		
		p.display();
	}

}
