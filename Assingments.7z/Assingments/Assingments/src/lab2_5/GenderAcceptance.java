package lab2_5;

public enum GenderAcceptance 
{
	M,F
}

