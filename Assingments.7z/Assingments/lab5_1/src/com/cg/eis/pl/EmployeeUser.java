package com.cg.eis.pl;

import com.cg.eis.bean.*;

import com.cg.eis.service.*;


public class EmployeeUser extends Impl {

	
		Impl impl;
		Employee emp;
		public EmployeeUser(){
		
			impl = new Impl();
			//emp = new Employee();
		}
	public static void main(String[] args) {
		
		
		EmployeeUser User = new EmployeeUser();
		
		User.emp=User.impl.getEmployeeDetails();
		
		User.impl.displayDetails(User.emp);

	}

}
