//global variable
var msg = "hi tej";

//var anyType;
document.write("<h2>value is <mark><i>"+anyType
+"</i></mark>datatype is<mark><i>"+typeof(anyType)+"</i></mark>");

anyType = "narendra";
document.write("<h2>value is <mark><i>"
+anyType+"</i></mark>datatype is<mark><i>"+typeof(anyType)+"</i></mark>");
//
function evenodd(n)
{
if(n%2==0)
alert("number is even");
else if(n==0)
alert("number is neither even nor odd");
else
alert("number is odd");
}
function checkMax(n1, n2)
{
var result = (n1 == n2)? 'both are equal'
:((n1>n2)?'ni is greater than n2': 'n2 is greater than n1');
alert(result);
}

function findFactorial(n)
{
var f=1;
for(var i=1;i<=n;i++)
f *=i;
alert(f);
}
//function 
function myConcat(separator)
{
    result="";
for(var i=1;i<arguments.length;i++)
result +=arguments[i] + separator;
var answer = "no of arguments"+arguments.length+"<br/>after concatation"+result;
return answer;
}